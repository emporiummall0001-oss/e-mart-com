import React, { useState, useRef } from 'react';
import {
  ArrowLeft,
  Star,
  Minus,
  Plus,
  Truck,
  ShieldCheck,
  MessageCircle,
  CheckCircle2,
  Copy,
  Check,
  Banknote,
  Sparkles,
  MapPin,
  Phone,
  User,
  FileText,
  ChevronLeft,
  ChevronRight,
} from 'lucide-react';
import { CODOrder, Product, StoreSettings } from '../types/store';
import {
  formatPKR,
  calculateDiscountPercent,
  buildWhatsAppUrl,
  buildProductShareUrl,
} from '../utils/helpers';
import { SafeImage } from './SafeImage';

interface ProductDetailPageProps {
  product: Product;
  settings: StoreSettings;
  relatedProducts: Product[];
  onBackToStore: () => void;
  onSelectProduct: (product: Product) => void;
  onSubmitCODOrder: (
    orderPayload: Omit<CODOrder, 'id' | 'orderNumber' | 'createdAt' | 'status'>
  ) => Promise<CODOrder>;
}

const PAKISTAN_CITIES = [
  'Karachi',
  'Lahore',
  'Islamabad',
  'Rawalpindi',
  'Faisalabad',
  'Multan',
  'Peshawar',
  'Quetta',
  'Sialkot',
  'Gujranwala',
  'Hyderabad',
  'Bahawalpur',
  'Sargodha',
  'Abbottabad',
  'Sukkur',
  'Mardan',
  'Other City',
];

export const ProductDetailPage: React.FC<ProductDetailPageProps> = ({
  product,
  settings,
  relatedProducts,
  onBackToStore,
  onSelectProduct,
  onSubmitCODOrder,
}) => {
  const [selectedImageIdx, setSelectedImageIdx] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const [copiedLink, setCopiedLink] = useState(false);

  // COD Form State (Supports English & Urdu)
  const [customerName, setCustomerName] = useState('');
  const [customerPhone, setCustomerPhone] = useState('');
  const [customerCity, setCustomerCity] = useState('Lahore');
  const [customerAddress, setCustomerAddress] = useState('');
  const [customerNotes, setCustomerNotes] = useState('');
  const [formLanguage, setFormLanguage] = useState<'bilingual' | 'urdu' | 'english'>('bilingual');
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState('');
  const [confirmedOrder, setConfirmedOrder] = useState<CODOrder | null>(null);

  const codFormRef = useRef<HTMLDivElement>(null);

  const galleryImages = (product.images || []).filter((img) => Boolean(img));
  const activeImage = galleryImages[selectedImageIdx] || galleryImages[0] || '';

  const discountPct = calculateDiscountPercent(product.price, product.oldPrice);
  const subtotal = product.price * quantity;
  const deliveryFee =
    subtotal >= (settings.freeDeliveryThreshold || 2500)
      ? 0
      : settings.codDeliveryFee || 200;
  const totalCODAmount = subtotal + deliveryFee;
  const totalSavings =
    product.oldPrice > product.price ? (product.oldPrice - product.price) * quantity : 0;

  const uniqueProductUrl = buildProductShareUrl(product.slug);

  const whatsappMessage = `Assalam-o-Alaikum ${settings.storeName}!\nI want to order on WhatsApp:\n\n*Product:* ${product.name}\n*Quantity:* ${quantity}\n*Unit Price:* ${formatPKR(product.price)}\n*Total COD Price:* ${formatPKR(totalCODAmount)}\n${
    customerName ? `*My Name:* ${customerName}\n` : ''
  }${customerPhone ? `*Phone:* ${customerPhone}\n` : ''}${
    customerAddress ? `*Address:* ${customerAddress}, ${customerCity}\n` : ''
  }*Product Link:* ${uniqueProductUrl}`;

  const whatsappDirectUrl = buildWhatsAppUrl(settings.whatsappNumber, whatsappMessage);

  const handleCopyProductLink = async () => {
    try {
      await navigator.clipboard.writeText(uniqueProductUrl);
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      setCopiedLink(true);
      setTimeout(() => setCopiedLink(false), 2500);
    }
  };

  const handleScrollToCODForm = () => {
    if (codFormRef.current) {
      codFormRef.current.scrollIntoView({ behavior: 'smooth', block: 'center' });
      const nameInput = codFormRef.current.querySelector('input');
      if (nameInput) nameInput.focus();
    }
  };

  const handlePlaceCODOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');

    if (!customerName.trim()) {
      setFormError('Please enter your Name / براہ کرم اپنا نام درج کریں');
      return;
    }
    if (!customerPhone.trim() || customerPhone.replace(/\D/g, '').length < 10) {
      setFormError(
        'Please enter a valid 11-digit Mobile Number (e.g. 0300-1234567) / درست موبائل نمبر درج کریں'
      );
      return;
    }
    if (!customerAddress.trim()) {
      setFormError('Please enter your complete delivery address / براہ کرم مکمل پتہ درج کریں');
      return;
    }

    setSubmitting(true);
    try {
      const created = await onSubmitCODOrder({
        productId: product.id,
        productName: product.name,
        productSlug: product.slug,
        productImage: activeImage,
        unitPrice: product.price,
        quantity,
        deliveryFee,
        totalAmount: totalCODAmount,
        customerName: customerName.trim(),
        customerPhone: customerPhone.trim(),
        customerCity: customerCity.trim() || 'Pakistan',
        customerAddress: customerAddress.trim(),
        customerNotes: customerNotes.trim(),
      });
      setConfirmedOrder(created);
    } catch (err) {
      setFormError(
        err instanceof Error ? err.message : 'Could not place order. Please try again.'
      );
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8">
      {/* Top Breadcrumb + Copy Meta Ad Product Link Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2 pb-4 mb-4 sm:mb-6 border-b border-stone-200/80">
        <div className="flex items-center gap-2 text-xs sm:text-sm text-stone-600">
          <button
            type="button"
            onClick={onBackToStore}
            className="inline-flex items-center gap-1.5 font-semibold text-stone-900 hover:text-emerald-700 transition-colors cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>Back to Shop</span>
          </button>
          <span aria-hidden="true">/</span>
          <span className="text-stone-500">{product.category}</span>
          <span aria-hidden="true" className="hidden sm:inline">
            /
          </span>
          <span className="hidden sm:inline text-stone-900 font-medium truncate max-w-xs">
            {product.name}
          </span>
        </div>

        <button
          type="button"
          onClick={handleCopyProductLink}
          className="inline-flex items-center gap-1.5 px-3 py-1.5 text-xs font-semibold bg-white hover:bg-stone-100 text-stone-800 border border-stone-300 rounded-lg transition-colors cursor-pointer"
          title="Copy direct product URL for Meta / Facebook Ads"
        >
          {copiedLink ? (
            <>
              <Check className="w-3.5 h-3.5 text-emerald-600" />
              <span className="text-emerald-700">Product Link Copied!</span>
            </>
          ) : (
            <>
              <Copy className="w-3.5 h-3.5 text-stone-500" />
              <span>Copy Product Link</span>
            </>
          )}
        </button>
      </div>

      {/* Main Two-Column Contiguous Purchase Module */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 lg:gap-10 items-start">
        {/* LEFT COLUMN: 5-Image Interactive Gallery */}
        <div className="lg:col-span-6 lg:sticky lg:top-28 space-y-3">
          <div className="relative aspect-square w-full rounded-2xl overflow-hidden bg-white border border-stone-200/90 shadow-sm">
            <SafeImage
              src={activeImage}
              alt={`${product.name} - Image ${selectedImageIdx + 1}`}
              className="w-full h-full object-cover object-center"
            />

            {/* Sale / Discount Badge */}
            {(product.discountBadge || discountPct > 0) && (
              <div className="absolute top-3 left-3 bg-red-600 text-white text-xs font-extrabold uppercase tracking-wider px-3 py-1.5 rounded-lg shadow">
                {product.discountBadge || `${discountPct}% OFF DEAL`}
              </div>
            )}

            {/* Prev / Next Gallery Arrows */}
            {galleryImages.length > 1 && (
              <>
                <button
                  type="button"
                  onClick={() =>
                    setSelectedImageIdx(
                      (prev) => (prev - 1 + galleryImages.length) % galleryImages.length
                    )
                  }
                  aria-label="Previous Product Image"
                  className="absolute left-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-stone-900 shadow border border-stone-200 flex items-center justify-center transition-transform hover:scale-105 cursor-pointer"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setSelectedImageIdx((prev) => (prev + 1) % galleryImages.length)
                  }
                  aria-label="Next Product Image"
                  className="absolute right-3 top-1/2 -translate-y-1/2 w-9 h-9 rounded-full bg-white/90 hover:bg-white text-stone-900 shadow border border-stone-200 flex items-center justify-center transition-transform hover:scale-105 cursor-pointer"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </>
            )}

            <div className="absolute bottom-3 right-3 bg-stone-950/75 text-white text-[11px] font-mono-tabular px-2.5 py-1 rounded-md">
              Image {selectedImageIdx + 1} of {galleryImages.length}
            </div>
          </div>

          {/* 5 Thumbnail Slots */}
          <div className="grid grid-cols-5 gap-2 sm:gap-3">
            {galleryImages.map((imgUrl, index) => {
              const isSelected = index === selectedImageIdx;
              return (
                <button
                  key={index}
                  type="button"
                  onClick={() => setSelectedImageIdx(index)}
                  className={`relative aspect-square rounded-xl overflow-hidden bg-white border transition-all cursor-pointer ${
                    isSelected
                      ? 'border-emerald-700 ring-2 ring-emerald-700/30 scale-[1.02]'
                      : 'border-stone-200 opacity-75 hover:opacity-100'
                  }`}
                >
                  <SafeImage
                    src={imgUrl}
                    alt={`${product.name} thumbnail ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              );
            })}
          </div>
        </div>

        {/* RIGHT COLUMN: Product Details, Blinking COD Button, WhatsApp Button & COD Form */}
        <div className="lg:col-span-6 space-y-6">
          {/* Category, Stock & 5-Star Rating Header */}
          <div className="space-y-2.5">
            <div className="flex flex-wrap items-center gap-2 text-xs font-semibold">
              <span className="text-emerald-800 uppercase tracking-wider">
                {product.category}
              </span>
              <span aria-hidden="true" className="text-stone-300">
                ·
              </span>
              <span
                className={
                  product.stockStatus === 'out_of_stock'
                    ? 'text-red-600'
                    : product.stockStatus === 'low_stock'
                    ? 'text-amber-700'
                    : 'text-emerald-700'
                }
              >
                {product.stockStatus === 'out_of_stock'
                  ? 'Out of Stock'
                  : product.stockStatus === 'low_stock'
                  ? `Low Stock (${product.stockCount} remaining)`
                  : `In Stock (${product.stockCount} units ready for dispatch)`}
              </span>
            </div>

            <h1 className="text-xl sm:text-2xl md:text-3xl font-extrabold text-stone-950 tracking-tight leading-snug">
              {product.name}
            </h1>

            {/* 5-Star Rating Section */}
            <div className="flex items-center gap-2 pt-0.5">
              <div className="flex items-center text-amber-400">
                {[1, 2, 3, 4, 5].map((star) => (
                  <Star
                    key={star}
                    className={`w-4 h-4 ${
                      star <= Math.round(product.rating || 5)
                        ? 'fill-amber-400 text-amber-400'
                        : 'fill-stone-200 text-stone-200'
                    }`}
                  />
                ))}
              </div>
              <span className="text-sm font-bold text-stone-900 font-mono-tabular">
                {(product.rating || 4.9).toFixed(1)} / 5.0
              </span>
              <span className="text-xs text-stone-500 font-mono-tabular">
                ({product.reviewsCount || 150} Verified Customer Reviews)
              </span>
            </div>
          </div>

          {/* Price, Old Price & Discount Block */}
          <div className="p-4 rounded-2xl bg-white border border-stone-200/90 space-y-2">
            <div className="flex items-baseline flex-wrap gap-3">
              <span className="text-2xl sm:text-3xl font-extrabold text-stone-950 font-mono-tabular">
                {formatPKR(product.price)}
              </span>
              {product.oldPrice > product.price && (
                <>
                  <span className="text-base sm:text-lg text-stone-400 line-through font-mono-tabular">
                    {formatPKR(product.oldPrice)}
                  </span>
                  <span className="text-xs font-extrabold text-red-600 font-mono-tabular">
                    Save {formatPKR(product.oldPrice - product.price)} ({discountPct}% OFF)
                  </span>
                </>
              )}
            </div>
            <p className="text-xs text-stone-500 flex items-center gap-1.5">
              <Truck className="w-3.5 h-3.5 text-emerald-700 shrink-0" />
              <span>
                {deliveryFee === 0
                  ? ' Eligible for FREE Cash on Delivery anywhere in Pakistan!'
                  : `Standard COD Delivery: ${formatPKR(deliveryFee)} (Free on orders over ${formatPKR(
                      settings.freeDeliveryThreshold
                    )})`}
              </span>
            </p>
          </div>

          {/* Quantity Selector */}
          <div className="flex flex-wrap items-center justify-between gap-4 p-4 rounded-2xl bg-white border border-stone-200/90">
            <div>
              <label className="block text-xs font-bold uppercase tracking-wider text-stone-500">
                Select Quantity / تعداد منتخب کریں
              </label>
              <span className="text-xs text-stone-600 font-mono-tabular">
                Subtotal: <strong className="text-stone-950">{formatPKR(subtotal)}</strong>
                {totalSavings > 0 && (
                  <span className="text-emerald-700 ml-1.5">
                    (You save {formatPKR(totalSavings)})
                  </span>
                )}
              </span>
            </div>

            <div className="flex items-center border border-stone-300 rounded-xl overflow-hidden bg-[#FAF9F6]">
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="w-10 h-10 flex items-center justify-center text-stone-700 hover:bg-stone-200 transition-colors cursor-pointer"
                aria-label="Decrease Quantity"
              >
                <Minus className="w-4 h-4" />
              </button>
              <span className="w-12 text-center text-base font-extrabold text-stone-950 font-mono-tabular select-none">
                {quantity}
              </span>
              <button
                type="button"
                onClick={() => setQuantity((q) => Math.min(20, q + 1))}
                className="w-10 h-10 flex items-center justify-center text-stone-700 hover:bg-stone-200 transition-colors cursor-pointer"
                aria-label="Increase Quantity"
              >
                <Plus className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Primary CTAs:
              1. Clearly Visible Blinking "Order Now – Cash on Delivery" Button
              2. Working "Order on WhatsApp" Button (Replacing Add to Cart) */}
          <div className="space-y-3">
            <button
              type="button"
              onClick={handleScrollToCODForm}
              className="animate-cod-button w-full py-4 px-5 bg-gradient-to-r from-red-600 via-red-600 to-amber-600 hover:from-red-700 hover:to-amber-700 text-white rounded-2xl font-extrabold text-sm sm:text-base tracking-wide shadow-lg flex items-center justify-center gap-2.5 cursor-pointer"
            >
              <span className="w-2.5 h-2.5 rounded-full bg-yellow-300 animate-cod-dot shrink-0" />
              <Banknote className="w-5 h-5 shrink-0" />
              <span>ORDER NOW – CASH ON DELIVERY ({formatPKR(totalCODAmount)})</span>
            </button>

            <a
              href={whatsappDirectUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="w-full py-3.5 px-5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-2xl font-bold text-sm sm:text-base shadow-sm flex items-center justify-center gap-2.5 transition-colors cursor-pointer"
            >
              <MessageCircle className="w-5 h-5 shrink-0" />
              <span>Order on WhatsApp (Instant Chat Confirmation)</span>
            </a>
          </div>

          {/* Product Description Section */}
          <div className="p-4 sm:p-5 rounded-2xl bg-white border border-stone-200/90 space-y-2.5">
            <h2 className="text-sm font-bold uppercase tracking-wider text-stone-500">
              Product Description & Specifications
            </h2>
            <p
              dir="auto"
              className="text-sm sm:text-[15px] text-stone-700 leading-relaxed whitespace-pre-line"
            >
              {product.description}
            </p>
            <div className="pt-3 border-t border-stone-100 grid grid-cols-2 sm:grid-cols-3 gap-2 text-xs text-stone-600">
              <div className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>7-Day Easy Return</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Truck className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>2–4 Days Delivery</span>
              </div>
              <div className="flex items-center gap-1.5">
                <Sparkles className="w-4 h-4 text-amber-500 shrink-0" />
                <span>Quality Inspected</span>
              </div>
            </div>
          </div>

          {/* CASH ON DELIVERY (COD) ORDER FORM (Supports English & Urdu) */}
          <div
            ref={codFormRef}
            id="cod-order-form-box"
            className="rounded-2xl bg-white border-2 border-stone-900 shadow-md overflow-hidden"
          >
            {/* Form Header */}
            <div className="bg-stone-950 text-white px-4 sm:px-6 py-4 flex flex-wrap items-center justify-between gap-2">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block">
                  Express Checkout · Pay When Parcel Arrives
                </span>
                <h2 className="text-base sm:text-lg font-extrabold">
                  Cash on Delivery Order Form / کیش آن ڈیلیوری فارم
                </h2>
              </div>

              {/* Language Label Helper Toggle */}
              <div className="flex items-center gap-1 bg-stone-800 p-1 rounded-lg text-[11px]">
                <button
                  type="button"
                  onClick={() => setFormLanguage('bilingual')}
                  className={`px-2 py-1 rounded font-semibold cursor-pointer ${
                    formLanguage === 'bilingual'
                      ? 'bg-emerald-600 text-white'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  Eng + اردو
                </button>
                <button
                  type="button"
                  onClick={() => setFormLanguage('urdu')}
                  className={`px-2 py-1 rounded font-semibold cursor-pointer ${
                    formLanguage === 'urdu'
                      ? 'bg-emerald-600 text-white'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  اردو
                </button>
                <button
                  type="button"
                  onClick={() => setFormLanguage('english')}
                  className={`px-2 py-1 rounded font-semibold cursor-pointer ${
                    formLanguage === 'english'
                      ? 'bg-emerald-600 text-white'
                      : 'text-stone-300 hover:text-white'
                  }`}
                >
                  English
                </button>
              </div>
            </div>

            {confirmedOrder ? (
              <div className="p-5 sm:p-6 space-y-4 bg-emerald-50/50">
                <div className="flex items-start gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-600 text-white flex items-center justify-center shrink-0 mt-0.5">
                    <CheckCircle2 className="w-6 h-6" />
                  </div>
                  <div className="space-y-1">
                    <span className="text-xs font-bold uppercase tracking-wider text-emerald-800">
                      Order Confirmed Successfully!
                    </span>
                    <h3 className="text-lg font-extrabold text-stone-950">
                      Thank You, {confirmedOrder.customerName}!
                    </h3>
                    <p className="text-xs sm:text-sm text-stone-600">
                      Your Cash on Delivery Order ID is{' '}
                      <strong className="font-mono-tabular text-stone-950 bg-amber-100 px-2 py-0.5 rounded">
                        {confirmedOrder.orderNumber}
                      </strong>
                      . Our dispatch team will verify and ship your parcel within 24 hours.
                    </p>
                  </div>
                </div>

                <div className="p-4 rounded-xl bg-white border border-stone-200 space-y-2 text-xs sm:text-sm">
                  <div className="flex justify-between">
                    <span className="text-stone-500">Product:</span>
                    <span className="font-semibold text-stone-900 text-right max-w-[220px] truncate">
                      {confirmedOrder.productName} (x{confirmedOrder.quantity})
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Customer Name:</span>
                    <span dir="auto" className="font-semibold text-stone-900">
                      {confirmedOrder.customerName}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Phone & City:</span>
                    <span className="font-semibold text-stone-900 font-mono-tabular">
                      {confirmedOrder.customerPhone} · {confirmedOrder.customerCity}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-stone-500">Delivery Address:</span>
                    <span dir="auto" className="font-semibold text-stone-900 text-right max-w-[240px]">
                      {confirmedOrder.customerAddress}
                    </span>
                  </div>
                  <div className="pt-2 border-t border-stone-100 flex justify-between text-base font-extrabold text-emerald-800 font-mono-tabular">
                    <span>Total Cash on Delivery:</span>
                    <span>{formatPKR(confirmedOrder.totalAmount)}</span>
                  </div>
                </div>

                <div className="flex flex-col sm:flex-row gap-2.5">
                  <a
                    href={buildWhatsAppUrl(
                      settings.whatsappNumber,
                      `Assalam-o-Alaikum! I just placed COD Order *${confirmedOrder.orderNumber}* on ${settings.storeName}.\nProduct: ${confirmedOrder.productName} (x${confirmedOrder.quantity})\nTotal COD: ${formatPKR(confirmedOrder.totalAmount)}\nName: ${confirmedOrder.customerName}\nAddress: ${confirmedOrder.customerAddress}, ${confirmedOrder.customerCity}`
                    )}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex-1 py-3 px-4 bg-emerald-700 hover:bg-emerald-800 text-white text-xs sm:text-sm font-bold rounded-xl flex items-center justify-center gap-2 text-center"
                  >
                    <MessageCircle className="w-4 h-4" />
                    <span>Send Order Receipt on WhatsApp</span>
                  </a>
                  <button
                    type="button"
                    onClick={() => setConfirmedOrder(null)}
                    className="py-3 px-4 bg-stone-200 hover:bg-stone-300 text-stone-800 text-xs sm:text-sm font-bold rounded-xl cursor-pointer"
                  >
                    Place Another Order
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handlePlaceCODOrder} className="p-4 sm:p-6 space-y-4">
                {formError && (
                  <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700">
                    {formError}
                  </div>
                )}

                {/* Field 1: Full Name (English or Urdu) */}
                <div>
                  <label className="flex items-center justify-between text-xs font-bold text-stone-800 mb-1.5">
                    <span className="inline-flex items-center gap-1.5">
                      <User className="w-3.5 h-3.5 text-emerald-700" />
                      {formLanguage === 'urdu'
                        ? 'آپ کا مکمل نام *'
                        : formLanguage === 'english'
                        ? 'Full Name *'
                        : 'Full Name / آپ کا مکمل نام *'}
                    </span>
                    <span className="text-[11px] font-normal text-stone-400">
                      English or اردو
                    </span>
                  </label>
                  <input
                    type="text"
                    dir="auto"
                    required
                    value={customerName}
                    onChange={(e) => setCustomerName(e.target.value)}
                    placeholder={
                      formLanguage === 'urdu'
                        ? 'اپنا نام یہاں لکھیں (مثلاً: محمد علی / عائشہ خان)'
                        : 'Enter your name (e.g. Muhammad Ali / محمد علی)'
                    }
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:bg-white focus:border-emerald-700"
                  />
                </div>

                {/* Field 2: Phone Number & City */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                  <div>
                    <label className="flex items-center gap-1.5 text-xs font-bold text-stone-800 mb-1.5">
                      <Phone className="w-3.5 h-3.5 text-emerald-700" />
                      <span>
                        {formLanguage === 'urdu'
                          ? 'موبائل / واٹس ایپ نمبر *'
                          : formLanguage === 'english'
                          ? 'Mobile / WhatsApp Number *'
                          : 'Phone Number / موبائل نمبر *'}
                      </span>
                    </label>
                    <input
                      type="tel"
                      required
                      value={customerPhone}
                      onChange={(e) => setCustomerPhone(e.target.value)}
                      placeholder="0300-1234567"
                      className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900 font-mono-tabular focus:outline-none focus:bg-white focus:border-emerald-700"
                    />
                  </div>

                  <div>
                    <label className="flex items-center gap-1.5 text-xs font-bold text-stone-800 mb-1.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                      <span>
                        {formLanguage === 'urdu'
                          ? 'شہر منتخب کریں *'
                          : formLanguage === 'english'
                          ? 'City *'
                          : 'City / شہر *'}
                      </span>
                    </label>
                    <select
                      value={customerCity}
                      onChange={(e) => setCustomerCity(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:bg-white focus:border-emerald-700"
                    >
                      {PAKISTAN_CITIES.map((city) => (
                        <option key={city} value={city}>
                          {city}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Field 3: Complete Delivery Address (Supports English & Urdu) */}
                <div>
                  <label className="flex items-center justify-between text-xs font-bold text-stone-800 mb-1.5">
                    <span className="inline-flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-emerald-700" />
                      {formLanguage === 'urdu'
                        ? 'مکمل پتہ (مکان نمبر، گلی، محلہ، مشہور جگہ) *'
                        : formLanguage === 'english'
                        ? 'Complete Delivery Address (House #, Street, Area) *'
                        : 'Complete Address / مکمل پتہ *'}
                    </span>
                    <span className="text-[11px] font-normal text-stone-400">
                      English or اردو
                    </span>
                  </label>
                  <textarea
                    rows={3}
                    dir="auto"
                    required
                    value={customerAddress}
                    onChange={(e) => setCustomerAddress(e.target.value)}
                    placeholder={
                      formLanguage === 'urdu'
                        ? 'مکان نمبر، گلی نمبر، بلاک/محلہ، قریبی مشہور جگہ اور شہر لکھیں...'
                        : 'House #, Street #, Sector/Block, Area & Landmark (یا اردو میں مکمل پتہ لکھیں)'
                    }
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:bg-white focus:border-emerald-700"
                  />
                </div>

                {/* Optional Notes */}
                <div>
                  <label className="flex items-center gap-1.5 text-xs font-bold text-stone-800 mb-1.5">
                    <FileText className="w-3.5 h-3.5 text-stone-500" />
                    <span>
                      {formLanguage === 'urdu'
                        ? 'خصوصی ہدایات (اختیاری)'
                        : 'Delivery Instructions / خصوصی ہدایات (Optional)'}
                    </span>
                  </label>
                  <input
                    type="text"
                    dir="auto"
                    value={customerNotes}
                    onChange={(e) => setCustomerNotes(e.target.value)}
                    placeholder="e.g. Call before arriving / شام کو ڈیلیور کریں"
                    className="w-full px-3.5 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-xs sm:text-sm text-stone-900 focus:outline-none focus:bg-white focus:border-emerald-700"
                  />
                </div>

                {/* Order Summary Box */}
                <div className="p-3.5 rounded-xl bg-stone-100/90 border border-stone-200/80 space-y-1.5 text-xs sm:text-sm">
                  <div className="flex justify-between text-stone-600">
                    <span>
                      Item Price ({quantity} {quantity === 1 ? 'item' : 'items'}):
                    </span>
                    <span className="font-mono-tabular font-semibold text-stone-900">
                      {formatPKR(subtotal)}
                    </span>
                  </div>
                  <div className="flex justify-between text-stone-600">
                    <span>COD Delivery Charges:</span>
                    <span className="font-mono-tabular font-semibold text-emerald-700">
                      {deliveryFee === 0 ? 'FREE' : formatPKR(deliveryFee)}
                    </span>
                  </div>
                  <div className="pt-1.5 border-t border-stone-200 flex justify-between text-sm sm:text-base font-extrabold text-stone-950 font-mono-tabular">
                    <span>Total Cash on Delivery:</span>
                    <span className="text-red-600">{formatPKR(totalCODAmount)}</span>
                  </div>
                </div>

                {/* Submit COD Order Button */}
                <button
                  type="submit"
                  disabled={submitting || product.stockStatus === 'out_of_stock'}
                  className="w-full py-3.5 px-6 bg-stone-950 hover:bg-emerald-700 disabled:bg-stone-400 text-white font-extrabold text-sm sm:text-base rounded-xl shadow-md transition-colors flex items-center justify-center gap-2 cursor-pointer"
                >
                  <CheckCircle2 className="w-5 h-5 text-emerald-400" />
                  <span>
                    {submitting
                      ? 'Confirming Your Order...'
                      : `Confirm Cash on Delivery Order — ${formatPKR(totalCODAmount)}`}
                  </span>
                </button>
              </form>
            )}
          </div>
        </div>
      </div>

      {/* Related Products Section */}
      {relatedProducts.length > 0 && (
        <div className="mt-14 pt-10 border-t border-stone-200">
          <h2 className="text-lg sm:text-xl font-bold text-stone-950 mb-5">
            You May Also Like from { settings.storeName }
          </h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 sm:gap-5">
            {relatedProducts.slice(0, 4).map((rel) => (
              <div
                key={rel.id}
                onClick={() => {
                  onSelectProduct(rel);
                  setSelectedImageIdx(0);
                  setQuantity(1);
                  setConfirmedOrder(null);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className="bg-white rounded-xl border border-stone-200 p-3 cursor-pointer hover:border-emerald-600 transition-colors"
              >
                <div className="aspect-square rounded-lg overflow-hidden bg-stone-100 mb-2.5">
                  <SafeImage
                    src={rel.images[0]}
                    alt={rel.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <p className="text-xs font-bold text-stone-900 line-clamp-2 mb-1">
                  {rel.name}
                </p>
                <span className="text-xs font-extrabold text-emerald-800 font-mono-tabular">
                  {formatPKR(rel.price)}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
