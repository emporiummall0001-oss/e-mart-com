import React from 'react';
import {
  RotateCcw,
  ShieldCheck,
  Wallet,
  MessageCircle,
  Phone,
  Mail,
  MapPin,
  Users,
  CheckCircle2,
  Lock,
} from 'lucide-react';
import {
  CategoryItem,
  ReturnPolicyContent,
  StoreSettings,
  VisitorStats,
} from '../types/store';
import { buildWhatsAppUrl } from '../utils/helpers';
import { SafeImage } from './SafeImage';

interface ReturnPolicyAndFooterProps {
  returnPolicy: ReturnPolicyContent;
  settings: StoreSettings;
  categories: CategoryItem[];
  visitorStats: VisitorStats;
  onSelectCategory: (slug: string) => void;
  onNavigateHome: () => void;
  onNavigateAdmin: () => void;
  onOpenTrackModal: () => void;
}

export const ReturnPolicyAndFooter: React.FC<ReturnPolicyAndFooterProps> = ({
  returnPolicy,
  settings,
  categories,
  visitorStats,
  onSelectCategory,
  onNavigateHome,
  onNavigateAdmin,
  onOpenTrackModal,
}) => {
  const whatsappUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    `Assalam-o-Alaikum ${settings.storeName}! I need assistance with an order / product.`
  );

  const highlightIcons = [RotateCcw, ShieldCheck, Wallet];

  return (
    <>
      {/* Return & Refund Policy Section at the Bottom */}
      <section
        id="return-refund-policy"
        aria-label="Return and Refund Policy"
        className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-10 sm:py-14"
      >
        <div className="rounded-3xl bg-white border border-stone-200/90 p-5 sm:p-8 lg:p-10 shadow-sm space-y-6">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-4 border-b border-stone-200/80 pb-6">
            <div className="space-y-1.5 max-w-2xl">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-emerald-700">
                <ShieldCheck className="w-4 h-4" />
                <span>100% Buyer Protection Guarantee · {returnPolicy.exchangeWindowDays}-Day Policy</span>
              </div>
              <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-stone-950 tracking-tight">
                {returnPolicy.heading}
              </h2>
              <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                {returnPolicy.subheading}
              </p>
            </div>

            <a
              href={buildWhatsAppUrl(
                settings.whatsappNumber,
                `Assalam-o-Alaikum ${settings.storeName}, I want to inquire about a return or exchange for my order.`
              )}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 px-4 py-2.5 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 rounded-xl text-xs font-bold transition-colors self-start md:self-auto whitespace-nowrap"
            >
              <MessageCircle className="w-4 h-4 text-emerald-700" />
              <span>Claim Return on WhatsApp</span>
            </a>
          </div>

          {/* 3 Policy Highlights */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 sm:gap-6">
            {(returnPolicy.highlights || []).map((item, idx) => {
              const IconComponent = highlightIcons[idx % highlightIcons.length];
              return (
                <div
                  key={idx}
                  className="p-4 sm:p-5 rounded-2xl bg-[#FAF9F6] border border-stone-200/80 space-y-2"
                >
                  <div className="w-9 h-9 rounded-xl bg-emerald-700/10 text-emerald-800 flex items-center justify-center">
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <h3 className="text-sm sm:text-base font-bold text-stone-950">
                    {item.title}
                  </h3>
                  <p className="text-xs sm:text-sm text-stone-600 leading-relaxed">
                    {item.description}
                  </p>
                </div>
              );
            })}
          </div>

          {/* Full Policy Terms */}
          <div className="pt-2 border-t border-stone-100 flex flex-col sm:flex-row sm:items-center justify-between gap-4 text-xs text-stone-600 leading-relaxed">
            <p className="max-w-4xl">{returnPolicy.fullPolicyText}</p>
            <div className="shrink-0 flex items-center gap-1.5 text-emerald-800 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Verified Pakistan COD Store</span>
            </div>
          </div>
        </div>
      </section>

      {/* Professional Store Footer */}
      <footer className="bg-stone-950 text-stone-300 border-t border-stone-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 sm:py-14">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-8 pb-10 border-b border-stone-800">
            {/* Brand & Store Overview */}
            <div className="lg:col-span-4 space-y-4">
              <div className="flex items-center gap-2.5">
                {settings.logoUrl ? (
                  <div className="h-9 max-w-[140px] rounded bg-white p-1">
                    <SafeImage
                      src={settings.logoUrl}
                      alt={settings.storeName}
                      className="h-full w-auto object-contain"
                    />
                  </div>
                ) : (
                  <div className="flex items-center gap-2.5">
                    <div className="w-9 h-9 rounded-xl bg-emerald-600 flex items-center justify-center text-white font-serif-editorial italic font-bold text-xl">
                      E
                    </div>
                    <span className="text-xl font-extrabold text-white tracking-tight">
                      {settings.storeName}
                    </span>
                  </div>
                )}
              </div>
              <p className="text-xs sm:text-sm text-stone-400 leading-relaxed max-w-sm">
                {settings.footerAboutText}
              </p>

              {/* Neat Live Store Visitor Counter Box in Footer */}
              <div className="inline-flex items-center gap-2.5 px-3.5 py-2 rounded-xl bg-stone-900 border border-stone-800 text-xs font-mono-tabular">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <Users className="w-3.5 h-3.5 text-emerald-400" />
                <span className="text-white font-bold">{visitorStats.liveVisitors}</span>
                <span className="text-stone-400">Active Shoppers</span>
                <span className="text-stone-700">·</span>
                <span className="text-stone-400">
                  {visitorStats.todayVisitors.toLocaleString()} visits today
                </span>
              </div>
            </div>

            {/* Categories Column */}
            <div className="lg:col-span-3 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Shop Categories
              </h3>
              <ul className="space-y-2 text-xs sm:text-sm">
                <li>
                  <button
                    type="button"
                    onClick={() => {
                      onSelectCategory('ALL');
                      onNavigateHome();
                    }}
                    className="text-stone-400 hover:text-white transition-colors cursor-pointer"
                  >
                    All Featured Products
                  </button>
                </li>
                {categories.map((cat) => (
                  <li key={cat.id}>
                    <button
                      type="button"
                      onClick={() => {
                        onSelectCategory(cat.slug);
                        onNavigateHome();
                      }}
                      className="text-stone-400 hover:text-white transition-colors cursor-pointer"
                    >
                      {cat.name}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Customer Care & Policies */}
            <div className="lg:col-span-2 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Customer Care
              </h3>
              <ul className="space-y-2 text-xs sm:text-sm">
                <li>
                  <button
                    type="button"
                    onClick={onOpenTrackModal}
                    className="text-stone-400 hover:text-white transition-colors cursor-pointer"
                  >
                    Track COD Order
                  </button>
                </li>
                <li>
                  <a
                    href="#return-refund-policy"
                    className="text-stone-400 hover:text-white transition-colors"
                  >
                    Return & Refund Policy
                  </a>
                </li>
                <li>
                  <a
                    href={whatsappUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-stone-400 hover:text-white transition-colors"
                  >
                    WhatsApp Order Help
                  </a>
                </li>
                <li>
                  <button
                    type="button"
                    onClick={onNavigateAdmin}
                    aria-label="Store Management"
                    className="inline-flex items-center justify-center w-7 h-7 rounded-lg bg-stone-900 text-stone-400 hover:text-emerald-400 border border-stone-800 transition-colors cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5" />
                  </button>
                </li>
              </ul>
            </div>

            {/* Contact & Dispatch Info */}
            <div className="lg:col-span-3 space-y-3">
              <h3 className="text-xs font-bold uppercase tracking-wider text-white">
                Contact & Dispatch Center
              </h3>
              <ul className="space-y-2.5 text-xs sm:text-sm text-stone-400">
                <li className="flex items-start gap-2">
                  <Phone className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span className="font-mono-tabular text-stone-200">
                    {settings.supportPhone}
                  </span>
                </li>
                <li className="flex items-start gap-2">
                  <Mail className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{settings.supportEmail}</span>
                </li>
                <li className="flex items-start gap-2">
                  <MapPin className="w-4 h-4 text-emerald-400 shrink-0 mt-0.5" />
                  <span>{settings.storeAddress}</span>
                </li>
              </ul>
              <div className="pt-2 text-[11px] text-stone-500">
                Courier Partners: TCS · Leopards Courier · M&P · PostEx Cash on Delivery
              </div>
            </div>
          </div>

          <div className="pt-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-stone-500">
            <p>
              © {new Date().getFullYear()} {settings.storeName} Pakistan. All rights reserved.
            </p>
            <p className="font-mono-tabular">
              100% Cash on Delivery · 7-Day Easy Return & Replacement
            </p>
          </div>
        </div>
      </footer>

      {/* Working Floating WhatsApp Button */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        aria-label="Chat with E Mart on WhatsApp"
        className="fixed bottom-4 right-4 z-40 flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-3 rounded-full shadow-lg border border-emerald-400/40 transition-transform hover:scale-105"
      >
        <MessageCircle className="w-5 h-5 fill-white/15" />
        <span className="text-xs font-extrabold tracking-wide hidden sm:inline">
          WhatsApp Support
        </span>
      </a>
    </>
  );
};
