import React from 'react';
import { LayoutGrid } from 'lucide-react';
import { CategoryItem, Product } from '../types/store';
import { SafeImage } from './SafeImage';

interface CategoryCirclesProps {
  categories: CategoryItem[];
  products: Product[];
  activeCategory: string;
  onSelectCategory: (slug: string) => void;
}

export const CategoryCircles: React.FC<CategoryCirclesProps> = ({
  categories,
  products,
  activeCategory,
  onSelectCategory,
}) => {
  const getCountForCategory = (slug: string) => {
    if (slug === 'ALL') return products.length;
    return products.filter(
      (p) => p.category.toLowerCase() === slug.toLowerCase()
    ).length;
  };

  return (
    <section
      aria-label="Shop by Category"
      className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-6 sm:py-9"
    >
      <div className="flex items-end justify-between mb-4 sm:mb-6">
        <div>
          <p className="text-[11px] sm:text-xs font-semibold uppercase tracking-wider text-emerald-800">
            Curated Collections
          </p>
          <h2 className="text-lg sm:text-2xl font-bold text-stone-950 tracking-tight">
            Shop by Category
          </h2>
        </div>
        {activeCategory !== 'ALL' && (
          <button
            type="button"
            onClick={() => onSelectCategory('ALL')}
            className="text-xs font-semibold text-emerald-700 hover:text-emerald-900 underline underline-offset-4 cursor-pointer"
          >
            View All ({products.length})
          </button>
        )}
      </div>

      {/* Responsive Circular Category Strip / Grid */}
      <div className="grid grid-cols-3 sm:grid-cols-6 gap-3 sm:gap-5">
        {/* All Categories Circle */}
        <button
          type="button"
          onClick={() => onSelectCategory('ALL')}
          className="group flex flex-col items-center text-center focus:outline-none cursor-pointer"
        >
          <div
            className={`w-20 h-20 xs:w-24 xs:h-24 sm:w-28 sm:h-28 rounded-full p-1 transition-all duration-200 ${
              activeCategory === 'ALL'
                ? 'ring-2 ring-emerald-700 bg-emerald-50 shadow-md scale-[1.03]'
                : 'ring-1 ring-stone-200/90 bg-white group-hover:ring-emerald-600/60 group-hover:scale-[1.02]'
            }`}
          >
            <div className="w-full h-full rounded-full bg-gradient-to-br from-stone-900 via-stone-800 to-emerald-950 flex flex-col items-center justify-center text-white">
              <LayoutGrid className="w-6 h-6 sm:w-7 sm:h-7 text-emerald-400 mb-1" />
              <span className="text-[10px] sm:text-xs font-bold tracking-tight">
                All Items
              </span>
            </div>
          </div>
          <span
            className={`mt-2 text-xs sm:text-sm font-bold tracking-tight transition-colors ${
              activeCategory === 'ALL' ? 'text-emerald-800' : 'text-stone-900 group-hover:text-emerald-700'
            }`}
          >
            All Products
          </span>
          <span className="text-[11px] text-stone-500 font-mono-tabular">
            {products.length} items
          </span>
        </button>

        {/* Individual Circular Category Cards */}
        {categories.map((cat) => {
          const isSelected = activeCategory === cat.slug;
          const count = getCountForCategory(cat.slug);
          return (
            <button
              key={cat.id}
              type="button"
              onClick={() => onSelectCategory(cat.slug)}
              className="group flex flex-col items-center text-center focus:outline-none cursor-pointer"
            >
              <div
                className={`w-20 h-20 xs:w-24 xs:h-24 sm:w-28 sm:h-28 rounded-full p-1 transition-all duration-200 ${
                  isSelected
                    ? 'ring-2 ring-emerald-700 bg-emerald-50 shadow-md scale-[1.03]'
                    : 'ring-1 ring-stone-200/90 bg-white group-hover:ring-emerald-600/60 group-hover:scale-[1.02]'
                }`}
              >
                <div className="w-full h-full rounded-full overflow-hidden bg-stone-100 relative">
                  <SafeImage
                    src={cat.image}
                    alt={cat.name}
                    className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                </div>
              </div>
              <span
                className={`mt-2 text-xs sm:text-sm font-bold tracking-tight line-clamp-1 transition-colors ${
                  isSelected ? 'text-emerald-800' : 'text-stone-900 group-hover:text-emerald-700'
                }`}
              >
                {cat.name}
              </span>
              <span className="text-[11px] text-stone-500 font-mono-tabular">
                {count} {count === 1 ? 'item' : 'items'}
              </span>
            </button>
          );
        })}
      </div>
    </section>
  );
};
