import React from 'react';
import { Star, ShoppingBag, MessageCircle } from 'lucide-react';
import { Product } from '../types/store';
import {
  formatPKR,
  calculateDiscountPercent,
  buildWhatsAppUrl,
  buildProductShareUrl,
} from '../utils/helpers';
import { SafeImage } from './SafeImage';

interface ProductCardProps {
  product: Product;
  whatsappNumber: string;
  onSelectProduct: (product: Product) => void;
}

export const ProductCard: React.FC<ProductCardProps> = ({
  product,
  whatsappNumber,
  onSelectProduct,
}) => {
  const discountPct = calculateDiscountPercent(product.price, product.oldPrice);
  const badgeText =
    product.discountBadge || (discountPct > 0 ? `${discountPct}% OFF DEAL` : '');

  const primaryImage =
    product.images && product.images.length > 0 ? product.images[0] : '';

  const productLink = buildProductShareUrl(product.slug);
  const whatsappOrderText = `Assalam-o-Alaikum E Mart! I want to order:\n*${product.name}*\nPrice: ${formatPKR(product.price)}\nProduct Link: ${productLink}`;
  const whatsappUrl = buildWhatsAppUrl(whatsappNumber, whatsappOrderText);

  const stockLabel =
    product.stockStatus === 'out_of_stock'
      ? 'Out of Stock'
      : product.stockStatus === 'low_stock'
      ? `Only ${product.stockCount} Left`
      : 'In Stock';

  return (
    <article className="group bg-white rounded-2xl border border-stone-200/90 overflow-hidden flex flex-col justify-between transition-all duration-200 hover:-translate-y-0.5 hover:shadow-md">
      {/* Top Image Area */}
      <div>
        <div
          onClick={() => onSelectProduct(product)}
          className="relative aspect-square w-full bg-[#F6F5F2] overflow-hidden cursor-pointer"
        >
          <SafeImage
            src={primaryImage}
            alt={product.name}
            className="w-full h-full object-cover object-center group-hover:scale-105 transition-transform duration-300"
          />

          {/* Sale / Deal Badge on Discounted Products */}
          {badgeText && (
            <div className="absolute top-2.5 left-2.5 z-10 bg-red-600 text-white text-[10px] sm:text-[11px] font-extrabold uppercase tracking-wider px-2.5 py-1 rounded-md shadow-sm">
              {badgeText}
            </div>
          )}

          {product.stockStatus === 'out_of_stock' && (
            <div className="absolute inset-0 bg-stone-950/60 flex items-center justify-center">
              <span className="bg-stone-900 text-white text-xs font-bold px-3 py-1.5 rounded-lg">
                Sold Out
              </span>
            </div>
          )}
        </div>

        {/* Card Content */}
        <div className="p-3 sm:p-4 space-y-2">
          {/* Unboxed Metadata: Category · Stock Status */}
          <div className="flex items-center gap-1.5 text-[11px] text-stone-500 font-medium truncate">
            <span className="truncate">{product.category}</span>
            <span aria-hidden="true">·</span>
            <span
              className={
                product.stockStatus === 'out_of_stock'
                  ? 'text-red-600 font-semibold'
                  : product.stockStatus === 'low_stock'
                  ? 'text-amber-700 font-semibold'
                  : 'text-emerald-700 font-semibold'
              }
            >
              {stockLabel}
            </span>
          </div>

          {/* Product Name */}
          <h3
            onClick={() => onSelectProduct(product)}
            className="text-xs sm:text-[15px] font-bold text-stone-900 line-clamp-2 leading-snug group-hover:text-emerald-800 transition-colors cursor-pointer min-h-[2.4rem]"
          >
            {product.name}
          </h3>

          {/* 5-Star Rating Section Under Every Product */}
          <div className="flex items-center gap-1.5 pt-0.5">
            <div className="flex items-center text-amber-500" aria-label={`Rated ${product.rating} out of 5 stars`}>
              {[1, 2, 3, 4, 5].map((star) => (
                <Star
                  key={star}
                  className={`w-3.5 h-3.5 ${
                    star <= Math.round(product.rating || 5)
                      ? 'fill-amber-400 text-amber-400'
                      : 'fill-stone-200 text-stone-200'
                  }`}
                />
              ))}
            </div>
            <span className="text-xs font-bold text-stone-800 font-mono-tabular">
              {(product.rating || 4.9).toFixed(1)}
            </span>
            <span className="text-[11px] text-stone-400 font-mono-tabular">
              ({product.reviewsCount || 120})
            </span>
          </div>

          {/* Price & Old Price */}
          <div className="pt-1 flex items-baseline flex-wrap gap-2">
            <span className="text-sm sm:text-lg font-extrabold text-stone-950 font-mono-tabular">
              {formatPKR(product.price)}
            </span>
            {product.oldPrice > product.price && (
              <span className="text-xs text-stone-400 line-through font-mono-tabular">
                {formatPKR(product.oldPrice)}
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Bottom Action Bar */}
      <div className="px-3 sm:px-4 pb-3 sm:pb-4 pt-1 flex items-center gap-1.5">
        <button
          type="button"
          onClick={() => onSelectProduct(product)}
          className="flex-1 py-2 px-2.5 bg-stone-900 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition-colors flex items-center justify-center gap-1.5 cursor-pointer whitespace-nowrap"
        >
          <ShoppingBag className="w-3.5 h-3.5 shrink-0" />
          <span>Order COD</span>
        </button>

        <a
          href={whatsappUrl}
          target="_blank"
          rel="noopener noreferrer"
          title="Order on WhatsApp"
          className="p-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 border border-emerald-200 rounded-xl transition-colors shrink-0 flex items-center justify-center"
        >
          <MessageCircle className="w-4 h-4 text-emerald-700" />
        </a>
      </div>
    </article>
  );
};
