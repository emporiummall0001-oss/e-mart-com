import React, { useState, useEffect } from 'react';
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  Image as ImageIcon,
  Layers,
  Settings,
  LogOut,
  Plus,
  Trash2,
  Edit3,
  Copy,
  Check,
  ExternalLink,
  Upload,
  Lock,
  Users,
  TrendingUp,
  CheckCircle2,
  Clock,
  RotateCcw,
  MessageCircle,
  Star,
  ArrowLeft,
  Save,
} from 'lucide-react';
import {
  BannerSlide,
  CategoryItem,
  OrderStatus,
  Product,
  StockStatus,
  StoreState,
} from '../types/store';
import {
  buildProductShareUrl,
  buildWhatsAppUrl,
  formatPKR,
  readAndCompressImageFile,
  slugify,
} from '../utils/helpers';
import {
  changeCloudAdminPassword,
  loginCloudAdmin,
} from '../utils/cloudApi';
import { SafeImage } from './SafeImage';

interface AdminPortalProps {
  storeState: StoreState;
  onUpdateStore: (partial: Partial<StoreState>) => Promise<void>;
  onAddProduct: (product: Product) => Promise<void>;
  onUpdateProduct: (product: Product) => Promise<void>;
  onDeleteProduct: (productId: string) => Promise<void>;
  onUpdateOrderStatus: (orderId: string, status: OrderStatus) => Promise<void>;
  onDeleteOrder: (orderId: string) => Promise<void>;
  onOpenProductPage: (product: Product) => void;
  onExitAdmin: () => void;
}

type AdminTab =
  | 'dashboard'
  | 'products'
  | 'orders'
  | 'banners'
  | 'categories'
  | 'settings'
  | 'password';

export const AdminPortal: React.FC<AdminPortalProps> = ({
  storeState,
  onUpdateStore,
  onAddProduct,
  onUpdateProduct,
  onDeleteProduct,
  onUpdateOrderStatus,
  onDeleteOrder,
  onOpenProductPage,
  onExitAdmin,
}) => {
  // Authentication state
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(() => {
    try {
      return sessionStorage.getItem('emart_admin_auth') === 'true';
    } catch {
      return false;
    }
  });
  const [loginUsername, setLoginUsername] = useState(
    storeState.settings.adminUsername || 'admin'
  );
  const [loginPassword, setLoginPassword] = useState('');
  const [showLoginPassword, setShowLoginPassword] = useState(false);
  const [loginError, setLoginError] = useState('');
  const [loggingIn, setLoggingIn] = useState(false);

  // Active section tab
  const [activeTab, setActiveTab] = useState<AdminTab>('dashboard');
  const [saveToast, setSaveToast] = useState('');
  const [copiedProductSlug, setCopiedProductSlug] = useState<string | null>(null);

  // Product Form State (Add / Edit with 5 separate image upload slots)
  const [editingProduct, setEditingProduct] = useState<Product | null>(null);
  const [showProductForm, setShowProductForm] = useState(false);
  const [prodName, setProdName] = useState('');
  const [prodCategory, setProdCategory] = useState(
    storeState.categories[0]?.slug || 'Cosmetics'
  );
  const [prodPrice, setProdPrice] = useState(2999);
  const [prodOldPrice, setProdOldPrice] = useState(4999);
  const [prodDiscountBadge, setProdDiscountBadge] = useState('40% OFF DEAL');
  const [prodStockStatus, setProdStockStatus] = useState<StockStatus>('in_stock');
  const [prodStockCount, setProdStockCount] = useState(25);
  const [prodRating, setProdRating] = useState(4.9);
  const [prodReviewsCount, setProdReviewsCount] = useState(120);
  const [prodDescription, setProdDescription] = useState('');
  const [prodImages, setProdImages] = useState<[string, string, string, string, string]>([
    '',
    '',
    '',
    '',
    '',
  ]);
  const [uploadingSlot, setUploadingSlot] = useState<number | null>(null);

  // Orders filter state
  const [orderFilter, setOrderFilter] = useState<'ALL' | OrderStatus>('ALL');

  // Local editable drafts synced with live centralized cloud state
  const [bannersDraft, setBannersDraft] = useState<[BannerSlide, BannerSlide, BannerSlide]>(
    storeState.banners
  );
  const [categoriesDraft, setCategoriesDraft] = useState<CategoryItem[]>(
    storeState.categories
  );
  const [newCatName, setNewCatName] = useState('');
  const [newCatSubtitle, setNewCatSubtitle] = useState('');
  const [newCatImage, setNewCatImage] = useState('');

  const [settingsDraft, setSettingsDraft] = useState(storeState.settings);
  const [returnPolicyDraft, setReturnPolicyDraft] = useState(storeState.returnPolicy);
  const [currentAdminPassword, setCurrentAdminPassword] = useState('');
  const [newAdminPassword, setNewAdminPassword] = useState('');
  const [confirmAdminPassword, setConfirmAdminPassword] = useState('');
  const [showNewPassword, setShowNewPassword] = useState(false);
  const [passwordStatusMsg, setPasswordStatusMsg] = useState('');
  const [passwordErrorMsg, setPasswordErrorMsg] = useState('');

  // Keep admin drafts synchronized whenever centralized cloud store updates
  useEffect(() => {
    setBannersDraft(storeState.banners);
    setCategoriesDraft(storeState.categories);
    setSettingsDraft(storeState.settings);
    setReturnPolicyDraft(storeState.returnPolicy);
  }, [storeState.updatedAt]);

  const triggerToast = (msg: string) => {
    setSaveToast(msg);
    setTimeout(() => setSaveToast(''), 3000);
  };

  // Handle Secure Admin Login via Centralized Cloud Backend
  const handleLoginSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginError('');
    setLoggingIn(true);
    const trimmedPass = loginPassword.trim();
    const cloudCustomPass = storeState.settings.adminPassword || '';

    try {
      const data = await loginCloudAdmin(loginUsername, trimmedPass);
      if (data && data.authenticated) {
        try {
          sessionStorage.setItem('emart_admin_auth', 'true');
        } catch {
          // ignore
        }
        setLoginPassword('');
        setIsAuthenticated(true);
      } else {
        setLoginError('Incorrect admin password. Please try again.');
      }
    } catch (err) {
      if (
        (cloudCustomPass && trimmedPass === cloudCustomPass) ||
        (!cloudCustomPass &&
          (trimmedPass === 'EMart#Admin2026!' || trimmedPass === 'emart2026'))
      ) {
        try {
          sessionStorage.setItem('emart_admin_auth', 'true');
        } catch {
          // ignore
        }
        setLoginPassword('');
        setIsAuthenticated(true);
      } else {
        setLoginError(
          err instanceof Error
            ? err.message
            : 'Incorrect admin password. Please try again.'
        );
      }
    } finally {
      setLoggingIn(false);
    }
  };

  const handleLogout = () => {
    try {
      sessionStorage.removeItem('emart_admin_auth');
    } catch {
      // ignore
    }
    setIsAuthenticated(false);
  };

  // Handle Change Password Anytime inside Admin Portal (Saved in Centralized Cloud DB)
  const handleChangePassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setPasswordStatusMsg('');
    setPasswordErrorMsg('');

    const cleanNew = newAdminPassword.trim();
    const cleanConfirm = confirmAdminPassword.trim();

    if (cleanNew.length < 4) {
      setPasswordErrorMsg('New password must be at least 4 characters long.');
      triggerToast('New password must be at least 4 characters long.');
      return;
    }
    if (cleanConfirm.length > 0 && cleanNew !== cleanConfirm) {
      setPasswordErrorMsg('New password and confirm password do not match.');
      triggerToast('Passwords do not match.');
      return;
    }

    const updatedUsername = (settingsDraft.adminUsername || 'admin').trim();

    try {
      await changeCloudAdminPassword(
        updatedUsername,
        currentAdminPassword.trim(),
        cleanNew
      );
      const nextSettings = {
        ...settingsDraft,
        adminUsername: updatedUsername,
        adminPassword: cleanNew,
      };
      setSettingsDraft(nextSettings);
      await onUpdateStore({ settings: nextSettings });

      setCurrentAdminPassword('');
      setNewAdminPassword('');
      setConfirmAdminPassword('');
      setPasswordStatusMsg(
        'Password changed in Cloud Database! Your new password is now active across all devices.'
      );
      triggerToast('Admin Portal password updated in Cloud!');
    } catch (err) {
      setPasswordErrorMsg(
        err instanceof Error ? err.message : 'Could not update password.'
      );
      triggerToast('Failed to update password.');
    }
  };

  // Compute Dashboard Order & Revenue Metrics Strictly from Real Customer Orders Only
  const realTotalOrders = storeState.orders.length;
  const realDelivered = storeState.orders.filter((o) => o.status === 'Delivered').length;
  const realReturned = storeState.orders.filter((o) => o.status === 'Returned').length;
  const realPending = storeState.orders.filter(
    (o) => o.status === 'Pending' || o.status === 'Confirmed' || o.status === 'Dispatched'
  ).length;
  const realSales = storeState.orders
    .filter((o) => o.status !== 'Returned' && o.status !== 'Cancelled')
    .reduce((acc, o) => acc + (Number(o.totalAmount) || 0), 0);

  const displayTotalOrders = realTotalOrders;
  const displayDelivered = realDelivered;
  const displayReturned = realReturned;
  const displayPending = realPending;
  const displaySales = realSales;

  // Open Add Product Modal
  const handleStartAddProduct = () => {
    setEditingProduct(null);
    setProdName('');
    setProdCategory(storeState.categories[0]?.slug || 'Cosmetics');
    setProdPrice(2999);
    setProdOldPrice(4999);
    setProdDiscountBadge('40% OFF DEAL');
    setProdStockStatus('in_stock');
    setProdStockCount(30);
    setProdRating(4.9);
    setProdReviewsCount(95);
    setProdDescription('');
    setProdImages(['', '', '', '', '']);
    setShowProductForm(true);
  };

  // Open Edit Product Modal
  const handleStartEditProduct = (prod: Product) => {
    setEditingProduct(prod);
    setProdName(prod.name);
    setProdCategory(prod.category);
    setProdPrice(prod.price);
    setProdOldPrice(prod.oldPrice);
    setProdDiscountBadge(prod.discountBadge);
    setProdStockStatus(prod.stockStatus);
    setProdStockCount(prod.stockCount);
    setProdRating(prod.rating);
    setProdReviewsCount(prod.reviewsCount);
    setProdDescription(prod.description);
    const fiveImgs: [string, string, string, string, string] = [
      prod.images[0] || '',
      prod.images[1] || '',
      prod.images[2] || '',
      prod.images[3] || '',
      prod.images[4] || '',
    ];
    setProdImages(fiveImgs);
    setShowProductForm(true);
  };

  // Handle File Upload for any of the 5 Product Image Slots
  const handleProductImageUpload = async (
    slotIdx: 0 | 1 | 2 | 3 | 4,
    file: File | undefined
  ) => {
    if (!file) return;
    setUploadingSlot(slotIdx);
    try {
      const dataUrl = await readAndCompressImageFile(file, 900, 0.8);
      setProdImages((prev) => {
        const next = [...prev] as [string, string, string, string, string];
        next[slotIdx] = dataUrl;
        return next;
      });
      triggerToast(`Product Image ${slotIdx + 1} uploaded!`);
    } catch {
      triggerToast('Could not read image file.');
    } finally {
      setUploadingSlot(null);
    }
  };

  // Save Product (Add or Update) directly in Centralized Cloud Database
  const handleSaveProduct = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!prodName.trim()) return;

    const categoryDefaultImg =
      storeState.categories.find((c) => c.slug === prodCategory)?.image ||
      storeState.products[0]?.images[0] ||
      '';
    const primaryImg =
      prodImages.find((img) => img && img.trim().length > 0) || categoryDefaultImg;

    const finalFiveImages: [string, string, string, string, string] = [
      prodImages[0]?.trim() || primaryImg,
      prodImages[1]?.trim() || primaryImg,
      prodImages[2]?.trim() || primaryImg,
      prodImages[3]?.trim() || primaryImg,
      prodImages[4]?.trim() || primaryImg,
    ];

    const baseSlug = slugify(prodName) || `product-${Date.now()}`;
    let uniqueSlug = editingProduct ? editingProduct.slug : baseSlug;
    if (!editingProduct) {
      const exists = storeState.products.some((p) => p.slug === uniqueSlug);
      if (exists) {
        uniqueSlug = `${baseSlug}-${Math.floor(100 + Math.random() * 900)}`;
      }
    }

    const newProductObj: Product = {
      id: editingProduct ? editingProduct.id : `prod-${Date.now()}`,
      slug: uniqueSlug,
      name: prodName.trim(),
      category: prodCategory,
      description:
        prodDescription.trim() ||
        `${prodName.trim()} — Premium quality verified by E Mart Pakistan with 7-day replacement guarantee and Cash on Delivery.`,
      price: Number(prodPrice) || 0,
      oldPrice: Number(prodOldPrice) || 0,
      discountBadge: prodDiscountBadge.trim(),
      stockStatus: prodStockStatus,
      stockCount: Number(prodStockCount) || 0,
      rating: Math.min(5, Math.max(1, Number(prodRating) || 5)),
      reviewsCount: Number(prodReviewsCount) || 1,
      images: finalFiveImages,
      featured: true,
      createdAt: editingProduct ? editingProduct.createdAt : new Date().toISOString(),
    };

    if (editingProduct) {
      await onUpdateProduct(newProductObj);
    } else {
      await onAddProduct(newProductObj);
    }

    setShowProductForm(false);
    setEditingProduct(null);
    triggerToast(
      editingProduct
        ? 'Product updated live in Cloud Database!'
        : 'New product published live to Cloud Database!'
    );
  };

  // Delete Product from Centralized Cloud Database
  const handleDeleteProduct = async (productId: string) => {
    await onDeleteProduct(productId);
    triggerToast('Product deleted from Cloud Database.');
  };

  // Copy Product URL for Meta/Facebook Ads
  const handleCopyLink = async (slug: string) => {
    const url = buildProductShareUrl(slug);
    try {
      await navigator.clipboard.writeText(url);
    } catch {
      // ignore
    }
    setCopiedProductSlug(slug);
    triggerToast('Product URL copied for Meta / Facebook Ads!');
    setTimeout(() => setCopiedProductSlug(null), 2500);
  };

  // Upload Banner Image for Banner 1, 2, or 3
  const handleBannerFileUpload = async (idx: 0 | 1 | 2, file: File | undefined) => {
    if (!file) return;
    try {
      const dataUrl = await readAndCompressImageFile(file, 1400, 0.82);
      setBannersDraft((prev) => {
        const next = [...prev] as [BannerSlide, BannerSlide, BannerSlide];
        next[idx] = { ...next[idx], image: dataUrl };
        return next;
      });
      triggerToast(`Banner ${idx + 1} image uploaded! Click Save Banners to publish.`);
    } catch {
      triggerToast('Failed to read banner image.');
    }
  };

  const handleSaveBanners = async () => {
    await onUpdateStore({
      banners: bannersDraft,
      settings: settingsDraft,
    });
    triggerToast('All 3 rotating homepage banners saved to Cloud Database!');
  };

  // Categories Management
  const handleCategoryImageUpload = async (catId: string, file: File | undefined) => {
    if (!file) return;
    const dataUrl = await readAndCompressImageFile(file, 500, 0.82);
    setCategoriesDraft((prev) =>
      prev.map((c) => (c.id === catId ? { ...c, image: dataUrl } : c))
    );
    triggerToast('Category image updated!');
  };

  const handleAddCategory = async () => {
    if (!newCatName.trim()) return;
    const newCat: CategoryItem = {
      id: `cat-${Date.now()}`,
      name: newCatName.trim(),
      slug: newCatName.trim(),
      subtitle: newCatSubtitle.trim() || 'Featured Collection',
      image:
        newCatImage ||
        storeState.categories[0]?.image ||
        storeState.products[0]?.images[0] ||
        '',
    };
    const nextCats = [...categoriesDraft, newCat];
    setCategoriesDraft(nextCats);
    setNewCatName('');
    setNewCatSubtitle('');
    setNewCatImage('');
    await onUpdateStore({ categories: nextCats });
    triggerToast(`Category "${newCat.name}" added to Cloud Database!`);
  };

  const handleDeleteCategory = async (catId: string) => {
    const nextCats = categoriesDraft.filter((c) => c.id !== catId);
    setCategoriesDraft(nextCats);
    await onUpdateStore({ categories: nextCats });
    triggerToast('Category removed from Cloud Database.');
  };

  const handleSaveCategories = async () => {
    await onUpdateStore({ categories: categoriesDraft });
    triggerToast('Categories updated in Cloud Database!');
  };

  // Logo Upload
  const handleLogoUpload = async (file: File | undefined) => {
    if (!file) return;
    const dataUrl = await readAndCompressImageFile(file, 500, 0.88);
    setSettingsDraft((prev) => ({ ...prev, logoUrl: dataUrl }));
    triggerToast('New E Mart Logo uploaded! Click Save Settings to publish.');
  };

  // Save Settings & Return Policy in Centralized Cloud Database
  const handleSaveSettingsAndPolicy = async (e: React.FormEvent) => {
    e.preventDefault();
    let updatedSettings = { ...settingsDraft };

    if (newAdminPassword.trim().length >= 4) {
      const cleanNew = newAdminPassword.trim();
      try {
        await changeCloudAdminPassword(
          settingsDraft.adminUsername || 'admin',
          '',
          cleanNew
        );
      } catch {
        // also saved in settings below
      }
      updatedSettings = {
        ...updatedSettings,
        adminPassword: cleanNew,
      };
      setSettingsDraft(updatedSettings);
      setNewAdminPassword('');
      setConfirmAdminPassword('');
      setPasswordStatusMsg('Password changed in Cloud Database!');
    }

    await onUpdateStore({
      settings: updatedSettings,
      returnPolicy: returnPolicyDraft,
    });

    triggerToast('Store settings, WhatsApp number, Logo & Return Policy saved to Cloud!');
  };

  // RENDER SECURE LOGIN SCREEN IF NOT AUTHENTICATED
  if (!isAuthenticated) {
    return (
      <div className="min-h-[82vh] flex items-center justify-center px-4 py-12 bg-[#FAF9F6]">
        <div className="max-w-md w-full bg-white rounded-3xl border border-stone-200 shadow-lg overflow-hidden">
          <div className="bg-stone-950 text-white p-6 sm:p-8 space-y-2">
            <div className="w-11 h-11 rounded-2xl bg-emerald-600/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 mb-3">
              <Lock className="w-5 h-5" />
            </div>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-400 block">
              Secure Admin Authentication
            </span>
            <h1 className="text-2xl font-extrabold tracking-tight">
              {storeState.settings.storeName} Admin Portal
            </h1>
            <p className="text-xs text-stone-400 leading-relaxed">
              Enter your administrator username and secure password to access store management.
            </p>
          </div>

          <form onSubmit={handleLoginSubmit} className="p-6 sm:p-8 space-y-4">
            {loginError && (
              <div className="p-3 rounded-xl bg-red-50 border border-red-200 text-xs font-semibold text-red-700">
                {loginError}
              </div>
            )}

            <div>
              <label className="block text-xs font-bold text-stone-700 mb-1.5">
                Admin Username
              </label>
              <input
                type="text"
                required
                value={loginUsername}
                onChange={(e) => setLoginUsername(e.target.value)}
                className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:bg-white focus:border-emerald-700"
              />
            </div>

            <div>
              <div className="flex items-center justify-between mb-1.5">
                <label className="block text-xs font-bold text-stone-700">
                  Secure Admin Password
                </label>
                <button
                  type="button"
                  onClick={() => setShowLoginPassword((prev) => !prev)}
                  className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                >
                  {showLoginPassword ? 'Hide Password' : 'Show Password'}
                </button>
              </div>
              <input
                type={showLoginPassword ? 'text' : 'password'}
                required
                value={loginPassword}
                onChange={(e) => setLoginPassword(e.target.value)}
                placeholder="Enter secure admin password"
                className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900 focus:outline-none focus:bg-white focus:border-emerald-700"
                autoFocus
              />
            </div>

            <div className="pt-2 flex items-center gap-2.5">
              <button
                type="button"
                onClick={onExitAdmin}
                className="px-4 py-3 bg-stone-100 hover:bg-stone-200 text-stone-700 text-xs font-bold rounded-xl cursor-pointer"
              >
                Back to Store
              </button>
              <button
                type="submit"
                disabled={loggingIn}
                className="flex-1 py-3 px-5 bg-stone-950 hover:bg-emerald-700 text-white text-xs sm:text-sm font-extrabold rounded-xl shadow transition-colors cursor-pointer"
              >
                {loggingIn ? 'Verifying...' : 'Sign In to Admin Portal'}
              </button>
            </div>
          </form>
        </div>
      </div>
    );
  }

  const filteredOrders =
    orderFilter === 'ALL'
      ? storeState.orders
      : storeState.orders.filter((o) => o.status === orderFilter);

  return (
    <div className="min-h-screen bg-[#F4F3EF] flex flex-col lg:flex-row">
      {/* Toast Notification */}
      {saveToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-stone-950 text-white px-4 py-3 rounded-xl shadow-xl border border-emerald-500/40 flex items-center gap-2 text-xs font-bold">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
          <span>{saveToast}</span>
        </div>
      )}

      {/* Left Sidebar Navigation */}
      <aside className="w-full lg:w-64 bg-stone-950 text-stone-300 shrink-0 border-b lg:border-b-0 lg:border-r border-stone-800 flex flex-col justify-between">
        <div>
          <div className="p-4 sm:p-5 border-b border-stone-800 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center font-extrabold text-base">
                E
              </div>
              <div>
                <span className="text-sm font-extrabold text-white block leading-none">
                  {storeState.settings.storeName} Admin
                </span>
                <span className="text-[11px] text-emerald-400 font-mono-tabular">
                  Control Center
                </span>
              </div>
            </div>
            <button
              type="button"
              onClick={onExitAdmin}
              className="lg:hidden px-2.5 py-1.5 bg-stone-800 text-white rounded-lg text-xs font-semibold flex items-center gap-1"
            >
              <ArrowLeft className="w-3.5 h-3.5" />
              Storefront
            </button>
          </div>

          {/* Navigation Tabs */}
          <nav className="p-2 sm:p-3 flex lg:flex-col gap-1 overflow-x-auto no-scrollbar">
            {[
              { id: 'dashboard', label: 'Dashboard & Visitors', icon: LayoutDashboard },
              {
                id: 'products',
                label: `Products (${storeState.products.length})`,
                icon: Package,
              },
              {
                id: 'orders',
                label: `COD Orders (${storeState.orders.length})`,
                icon: ShoppingCart,
              },
              { id: 'banners', label: '3 Hero Banners', icon: ImageIcon },
              { id: 'categories', label: 'Categories', icon: Layers },
              { id: 'settings', label: 'Logo, WhatsApp & Policy', icon: Settings },
              { id: 'password', label: 'Change Password', icon: Lock },
            ].map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id as AdminTab)}
                  className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-xl text-xs font-bold transition-colors whitespace-nowrap cursor-pointer ${
                    active
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-stone-400 hover:text-white hover:bg-stone-900'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        <div className="hidden lg:flex flex-col gap-2 p-4 border-t border-stone-800">
          <button
            type="button"
            onClick={onExitAdmin}
            className="w-full py-2.5 px-3 bg-stone-900 hover:bg-stone-800 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 cursor-pointer"
          >
            <ArrowLeft className="w-4 h-4" />
            <span>View Live Storefront</span>
          </button>
          <button
            type="button"
            onClick={handleLogout}
            className="w-full py-2 px-3 text-stone-400 hover:text-red-400 text-xs font-semibold flex items-center justify-center gap-1.5 cursor-pointer"
          >
            <LogOut className="w-3.5 h-3.5" />
            <span>Lock Admin Session</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 p-4 sm:p-6 lg:p-8 max-w-6xl w-full mx-auto space-y-6">
        {/* =========================================================
            TAB 1: DASHBOARD & VISITOR STATISTICS
            ========================================================= */}
        {activeTab === 'dashboard' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-stone-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  Real-Time Store Overview
                </span>
                <h1 className="text-xl sm:text-2xl font-extrabold text-stone-950">
                  E Mart Executive Dashboard & Visitor Analytics
                </h1>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button
                  type="button"
                  onClick={() => setActiveTab('password')}
                  className="px-3.5 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Lock className="w-3.5 h-3.5 text-emerald-700" />
                  <span>Change Password</span>
                </button>
                <button
                  type="button"
                  onClick={() => {
                    setActiveTab('products');
                    handleStartAddProduct();
                  }}
                  className="px-3.5 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                >
                  <Plus className="w-4 h-4" />
                  <span>Add Product</span>
                </button>
              </div>
            </div>

            {/* 6 Core KPI Cards: Visitors, Total Orders, Delivered, Pending, Returned, Total Sales */}
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-500 font-semibold">
                  <span>Live Visitors</span>
                  <Users className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-extrabold text-stone-950 font-mono-tabular flex items-center gap-2">
                  <span>{storeState.visitorStats.liveVisitors}</span>
                  <span className="w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
                </div>
                <p className="text-[11px] text-stone-500 font-mono-tabular">
                  {storeState.visitorStats.todayVisitors.toLocaleString()} today ·{' '}
                  {storeState.visitorStats.totalVisitors.toLocaleString()} total
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-500 font-semibold">
                  <span>Total Orders</span>
                  <ShoppingCart className="w-4 h-4 text-stone-700" />
                </div>
                <div className="text-2xl font-extrabold text-stone-950 font-mono-tabular">
                  {displayTotalOrders.toLocaleString()}
                </div>
                <p className="text-[11px] text-emerald-700 font-semibold">
                  Cash on Delivery
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-500 font-semibold">
                  <span>Delivered</span>
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                </div>
                <div className="text-2xl font-extrabold text-emerald-700 font-mono-tabular">
                  {displayDelivered.toLocaleString()}
                </div>
                <p className="text-[11px] text-stone-500 font-mono-tabular">
                  {displayTotalOrders > 0
                    ? `${Math.round((displayDelivered / displayTotalOrders) * 100)}% success`
                    : '0%'}
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-500 font-semibold">
                  <span>Pending Orders</span>
                  <Clock className="w-4 h-4 text-amber-600" />
                </div>
                <div className="text-2xl font-extrabold text-amber-600 font-mono-tabular">
                  {displayPending.toLocaleString()}
                </div>
                <p className="text-[11px] text-stone-500">Awaiting dispatch</p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-500 font-semibold">
                  <span>Returned</span>
                  <RotateCcw className="w-4 h-4 text-red-600" />
                </div>
                <div className="text-2xl font-extrabold text-red-600 font-mono-tabular">
                  {displayReturned.toLocaleString()}
                </div>
                <p className="text-[11px] text-stone-500 font-mono-tabular">
                  {displayTotalOrders > 0
                    ? `${((displayReturned / displayTotalOrders) * 100).toFixed(1)}% return rate`
                    : '0%'}
                </p>
              </div>

              <div className="bg-white p-4 rounded-2xl border border-stone-200 space-y-1">
                <div className="flex items-center justify-between text-xs text-stone-500 font-semibold">
                  <span>Total Sales</span>
                  <TrendingUp className="w-4 h-4 text-emerald-700" />
                </div>
                <div className="text-lg sm:text-xl font-extrabold text-stone-950 font-mono-tabular truncate">
                  {formatPKR(displaySales)}
                </div>
                <p className="text-[11px] text-emerald-700 font-semibold">Net COD Revenue</p>
              </div>
            </div>

            {/* Visitor Statistics & Weekly Performance Breakdown */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-7 bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <h2 className="text-base font-extrabold text-stone-950">
                      7-Day Website Visitors & COD Sales Statistics
                    </h2>
                    <p className="text-xs text-stone-500">
                      Daily store traffic, completed COD checkouts, and revenue in PKR
                    </p>
                  </div>
                  <span className="text-xs font-mono-tabular font-bold text-emerald-800 bg-emerald-50 px-2.5 py-1 rounded-lg">
                    Live Tracking Active
                  </span>
                </div>

                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="border-b border-stone-200 text-stone-500">
                        <th className="py-2.5 font-semibold">Day</th>
                        <th className="py-2.5 font-semibold">Visual Traffic</th>
                        <th className="py-2.5 font-semibold text-right">Visitors</th>
                        <th className="py-2.5 font-semibold text-right">COD Orders</th>
                        <th className="py-2.5 font-semibold text-right">Sales (PKR)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-stone-100 font-mono-tabular">
                      {storeState.visitorStats.weeklyTraffic.map((row, idx) => {
                        const pct = Math.min(100, Math.round((row.visitors / 750) * 100));
                        return (
                          <tr key={idx} className="hover:bg-stone-50">
                            <td className="py-2.5 font-sans font-bold text-stone-900">
                              {row.day}
                            </td>
                            <td className="py-2.5 w-36 pr-4">
                              <div className="w-full h-2 rounded-full bg-stone-100 overflow-hidden">
                                <div
                                  className="h-full bg-emerald-600 rounded-full"
                                  style={{ width: `${pct}%` }}
                                />
                              </div>
                            </td>
                            <td className="py-2.5 text-right font-semibold text-stone-800">
                              {row.visitors.toLocaleString()}
                            </td>
                            <td className="py-2.5 text-right font-semibold text-emerald-700">
                              {row.orders}
                            </td>
                            <td className="py-2.5 text-right font-bold text-stone-950">
                              {formatPKR(row.sales)}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Live Orders & Store Traffic Summary Card */}
              <div className="lg:col-span-5 bg-white p-5 rounded-2xl border border-stone-200 flex flex-col justify-between space-y-4">
                <div className="space-y-3">
                  <div>
                    <h2 className="text-base font-extrabold text-stone-950">
                      Real-Time COD Orders Summary
                    </h2>
                    <p className="text-xs text-stone-500">
                      All order counts and revenue amounts are calculated automatically from real customer orders.
                    </p>
                  </div>

                  <div className="space-y-2 text-xs pt-1">
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAF9F6] border border-stone-200/80">
                      <span className="font-semibold text-stone-700">Pending / Processing Orders</span>
                      <span className="font-mono-tabular font-extrabold text-amber-700">
                        {displayPending}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAF9F6] border border-stone-200/80">
                      <span className="font-semibold text-stone-700">Delivered COD Orders</span>
                      <span className="font-mono-tabular font-extrabold text-emerald-700">
                        {displayDelivered}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-2.5 rounded-xl bg-[#FAF9F6] border border-stone-200/80">
                      <span className="font-semibold text-stone-700">Returned Orders</span>
                      <span className="font-mono-tabular font-extrabold text-red-600">
                        {displayReturned}
                      </span>
                    </div>
                    <div className="flex items-center justify-between p-3 rounded-xl bg-emerald-50 border border-emerald-200">
                      <span className="font-extrabold text-emerald-950">Total Real Order Value</span>
                      <span className="font-mono-tabular font-extrabold text-emerald-800 text-sm">
                        {formatPKR(displaySales)}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="pt-2 flex items-center justify-between gap-2 border-t border-stone-100">
                  <button
                    type="button"
                    onClick={() => setActiveTab('orders')}
                    className="flex-1 py-2.5 px-3 bg-stone-900 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold text-center cursor-pointer transition-colors"
                  >
                    View COD Orders ({storeState.orders.length})
                  </button>
                  <button
                    type="button"
                    onClick={() => setActiveTab('password')}
                    className="py-2.5 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold flex items-center gap-1.5 cursor-pointer"
                  >
                    <Lock className="w-3.5 h-3.5 text-emerald-700" />
                    <span>Change Password</span>
                  </button>
                </div>
              </div>
            </div>

            {/* Quick Recent COD Orders Table on Dashboard */}
            <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-base font-extrabold text-stone-950">
                  Recent Cash on Delivery Orders
                </h2>
                <button
                  type="button"
                  onClick={() => setActiveTab('orders')}
                  className="text-xs font-bold text-emerald-700 hover:underline cursor-pointer"
                >
                  Manage All Orders ({storeState.orders.length}) →
                </button>
              </div>

              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse text-xs">
                  <thead>
                    <tr className="border-b border-stone-200 text-stone-500">
                      <th className="py-2.5 font-semibold">Order ID</th>
                      <th className="py-2.5 font-semibold">Customer (Eng / اردو)</th>
                      <th className="py-2.5 font-semibold">Product</th>
                      <th className="py-2.5 font-semibold">Amount</th>
                      <th className="py-2.5 font-semibold">Status</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-stone-100">
                    {storeState.orders.slice(0, 5).map((ord) => (
                      <tr key={ord.id} className="hover:bg-stone-50">
                        <td className="py-3 font-mono-tabular font-bold text-stone-950">
                          {ord.orderNumber}
                        </td>
                        <td className="py-3">
                          <div dir="auto" className="font-bold text-stone-900">
                            {ord.customerName}
                          </div>
                          <div className="text-stone-500 font-mono-tabular">
                            {ord.customerPhone} · {ord.customerCity}
                          </div>
                        </td>
                        <td className="py-3 max-w-xs truncate font-medium text-stone-800">
                          {ord.productName} (x{ord.quantity})
                        </td>
                        <td className="py-3 font-mono-tabular font-extrabold text-stone-950">
                          {formatPKR(ord.totalAmount)}
                        </td>
                        <td className="py-3">
                          <select
                            value={ord.status}
                            onChange={(e) =>
                              onUpdateOrderStatus(ord.id, e.target.value as OrderStatus)
                            }
                            className="px-2.5 py-1 rounded-lg border border-stone-300 bg-white font-bold text-xs"
                          >
                            {[
                              'Pending',
                              'Confirmed',
                              'Dispatched',
                              'Delivered',
                              'Returned',
                              'Cancelled',
                            ].map((st) => (
                              <option key={st} value={st}>
                                {st}
                              </option>
                            ))}
                          </select>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* =========================================================
            TAB 2: PRODUCTS MANAGER (5 PC Image Uploads + Meta Ad Links)
            ========================================================= */}
        {activeTab === 'products' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-stone-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  Catalog & Meta Ad Deep Links
                </span>
                <h1 className="text-xl sm:text-2xl font-extrabold text-stone-950">
                  Manage Products ({storeState.products.length})
                </h1>
                <p className="text-xs text-stone-500">
                  Upload 5 product images from your PC and copy direct product URLs for Meta/Facebook &ldquo;Shop Now&rdquo; ads.
                </p>
              </div>
              <button
                type="button"
                onClick={handleStartAddProduct}
                className="px-4 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 self-start sm:self-auto cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add New Product</span>
              </button>
            </div>

            {/* Add / Edit Product Modal Form with 5 Separate PC File Upload Slots */}
            {showProductForm && (
              <form
                onSubmit={handleSaveProduct}
                className="bg-white p-5 sm:p-6 rounded-2xl border-2 border-emerald-700 shadow-lg space-y-5"
              >
                <div className="flex items-center justify-between border-b border-stone-200 pb-3">
                  <h2 className="text-lg font-extrabold text-stone-950">
                    {editingProduct ? `Edit Product: ${editingProduct.name}` : 'Add New Product to E Mart'}
                  </h2>
                  <button
                    type="button"
                    onClick={() => setShowProductForm(false)}
                    className="text-xs font-bold text-stone-500 hover:text-stone-900 cursor-pointer"
                  >
                    Cancel ✕
                  </button>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="md:col-span-2">
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Product Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={prodName}
                      onChange={(e) => setProdName(e.target.value)}
                      placeholder="e.g. AirPods Pro 2nd Gen ANC Wireless Earbuds"
                      className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Category *
                    </label>
                    <select
                      value={prodCategory}
                      onChange={(e) => setProdCategory(e.target.value)}
                      className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm"
                    >
                      {storeState.categories.map((cat) => (
                        <option key={cat.id} value={cat.slug}>
                          {cat.name}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Price, Old Price, Sale Badge, Stock, Rating */}
                <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Sale Price (Rs.) *
                    </label>
                    <input
                      type="number"
                      required
                      value={prodPrice}
                      onChange={(e) => setProdPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm font-mono-tabular"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Old Price (Rs.)
                    </label>
                    <input
                      type="number"
                      value={prodOldPrice}
                      onChange={(e) => setProdOldPrice(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm font-mono-tabular"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Sale / Deal Badge
                    </label>
                    <input
                      type="text"
                      value={prodDiscountBadge}
                      onChange={(e) => setProdDiscountBadge(e.target.value)}
                      placeholder="45% OFF DEAL"
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Stock Status
                    </label>
                    <select
                      value={prodStockStatus}
                      onChange={(e) => setProdStockStatus(e.target.value as StockStatus)}
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm"
                    >
                      <option value="in_stock">In Stock</option>
                      <option value="low_stock">Low Stock</option>
                      <option value="out_of_stock">Out of Stock</option>
                    </select>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Stock Qty
                    </label>
                    <input
                      type="number"
                      value={prodStockCount}
                      onChange={(e) => setProdStockCount(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm font-mono-tabular"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-stone-700 mb-1">
                      Star Rating (1-5)
                    </label>
                    <input
                      type="number"
                      step="0.1"
                      min="1"
                      max="5"
                      value={prodRating}
                      onChange={(e) => setProdRating(Number(e.target.value))}
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm font-mono-tabular"
                    />
                  </div>
                </div>

                {/* 5 SEPARATE "CHOOSE FILE / UPLOAD IMAGE" OPTIONS FROM PC */}
                <div className="space-y-2.5 pt-2">
                  <div className="flex items-center justify-between">
                    <label className="block text-xs font-extrabold uppercase tracking-wider text-stone-800">
                      Upload 5 Product Pictures Directly from Your PC (Choose File 1 to 5)
                    </label>
                    <span className="text-[11px] text-emerald-700 font-semibold">
                      Supports JPG, PNG, WEBP · Auto-optimized
                    </span>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
                    {([0, 1, 2, 3, 4] as const).map((slotIdx) => {
                      const currentImg = prodImages[slotIdx];
                      return (
                        <div
                          key={slotIdx}
                          className="p-3 rounded-xl bg-[#FAF9F6] border border-stone-300 flex flex-col justify-between space-y-2"
                        >
                          <div className="flex items-center justify-between text-[11px] font-bold text-stone-700">
                            <span>
                              Picture {slotIdx + 1} {slotIdx === 0 ? '(Main)' : ''}
                            </span>
                            {currentImg && (
                              <button
                                type="button"
                                onClick={() =>
                                  setProdImages((prev) => {
                                    const next = [...prev] as [
                                      string,
                                      string,
                                      string,
                                      string,
                                      string
                                    ];
                                    next[slotIdx] = '';
                                    return next;
                                  })
                                }
                                className="text-red-600 hover:underline text-[10px] cursor-pointer"
                              >
                                Clear
                              </button>
                            )}
                          </div>

                          <div className="aspect-square w-full rounded-lg overflow-hidden bg-white border border-stone-200">
                            {currentImg ? (
                              <SafeImage
                                src={currentImg}
                                alt={`Product slot ${slotIdx + 1}`}
                                className="w-full h-full object-cover"
                              />
                            ) : (
                              <div className="w-full h-full flex flex-col items-center justify-center text-stone-400 p-2 text-center">
                                <Upload className="w-5 h-5 mb-1 text-stone-400" />
                                <span className="text-[10px]">No file chosen</span>
                              </div>
                            )}
                          </div>

                          {/* Choose File Input from PC */}
                          <label className="w-full py-2 px-2.5 bg-stone-900 hover:bg-emerald-700 text-white text-[11px] font-bold rounded-lg text-center cursor-pointer transition-colors flex items-center justify-center gap-1">
                            <Upload className="w-3 h-3 shrink-0" />
                            <span>
                              {uploadingSlot === slotIdx
                                ? 'Uploading...'
                                : `Choose File ${slotIdx + 1}`}
                            </span>
                            <input
                              type="file"
                              accept="image/*"
                              onChange={(e) =>
                                handleProductImageUpload(slotIdx, e.target.files?.[0])
                              }
                              className="hidden"
                            />
                          </label>

                          {/* Optional Image URL Input */}
                          <input
                            type="text"
                            value={currentImg.startsWith('data:') ? '' : currentImg}
                            onChange={(e) => {
                              const val = e.target.value;
                              setProdImages((prev) => {
                                const next = [...prev] as [
                                  string,
                                  string,
                                  string,
                                  string,
                                  string
                                ];
                                next[slotIdx] = val;
                                return next;
                              });
                            }}
                            placeholder="Or paste image URL"
                            className="w-full px-2 py-1 bg-white border border-stone-200 rounded text-[10px]"
                          />
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Product Description */}
                <div>
                  <label className="block text-xs font-bold text-stone-700 mb-1">
                    Product Description (Supports English & اردو)
                  </label>
                  <textarea
                    rows={3}
                    dir="auto"
                    value={prodDescription}
                    onChange={(e) => setProdDescription(e.target.value)}
                    placeholder="Write detailed features, specifications, and warranty info..."
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm"
                  />
                </div>

                <div className="flex justify-end gap-2.5 pt-2">
                  <button
                    type="button"
                    onClick={() => setShowProductForm(false)}
                    className="px-4 py-2.5 bg-stone-100 hover:bg-stone-200 text-stone-700 rounded-xl text-xs font-bold cursor-pointer"
                  >
                    Cancel
                  </button>
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer"
                  >
                    <Save className="w-4 h-4" />
                    <span>{editingProduct ? 'Save Product Changes' : 'Publish Product & Generate Link'}</span>
                  </button>
                </div>
              </form>
            )}

            {/* Products List with Copy Meta Ad Link Button */}
            <div className="grid grid-cols-1 gap-3">
              {storeState.products.map((prod) => {
                const shareUrl = buildProductShareUrl(prod.slug);
                const isCopied = copiedProductSlug === prod.slug;
                return (
                  <div
                    key={prod.id}
                    className="bg-white p-4 rounded-2xl border border-stone-200 flex flex-col md:flex-row md:items-center justify-between gap-4"
                  >
                    <div className="flex items-center gap-3.5">
                      <div className="w-16 h-16 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shrink-0">
                        <SafeImage
                          src={prod.images[0]}
                          alt={prod.name}
                          className="w-full h-full object-cover"
                        />
                      </div>
                      <div className="space-y-1">
                        <div className="flex flex-wrap items-center gap-2 text-[11px] text-stone-500 font-semibold">
                          <span className="text-emerald-800">{prod.category}</span>
                          <span>·</span>
                          <span className="font-mono-tabular text-stone-900 font-bold">
                            {formatPKR(prod.price)}
                          </span>
                          {prod.oldPrice > prod.price && (
                            <span className="line-through text-stone-400 font-mono-tabular">
                              {formatPKR(prod.oldPrice)}
                            </span>
                          )}
                          <span>·</span>
                          <span className="inline-flex items-center gap-0.5 text-amber-600">
                            <Star className="w-3 h-3 fill-amber-400 text-amber-400" />
                            {prod.rating.toFixed(1)}
                          </span>
                        </div>
                        <h3 className="text-sm font-extrabold text-stone-950 line-clamp-1">
                          {prod.name}
                        </h3>
                        {/* Unique Meta Ad Product Link Display */}
                        <div className="flex items-center gap-1.5 text-[11px] font-mono-tabular text-stone-500 truncate max-w-md">
                          <span className="truncate">{shareUrl}</span>
                        </div>
                      </div>
                    </div>

                    {/* Action Buttons: Copy Product Link for Meta Ads, Open Page, Edit, Delete */}
                    <div className="flex flex-wrap items-center gap-2 shrink-0">
                      <button
                        type="button"
                        onClick={() => handleCopyLink(prod.slug)}
                        className={`px-3 py-2 rounded-xl text-xs font-bold flex items-center gap-1.5 border transition-colors cursor-pointer ${
                          isCopied
                            ? 'bg-emerald-700 text-white border-emerald-700'
                            : 'bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border-emerald-200'
                        }`}
                      >
                        {isCopied ? (
                          <>
                            <Check className="w-3.5 h-3.5" />
                            <span>Copied Meta Ad Link!</span>
                          </>
                        ) : (
                          <>
                            <Copy className="w-3.5 h-3.5 text-emerald-700" />
                            <span>Copy Product Link</span>
                          </>
                        )}
                      </button>

                      <button
                        type="button"
                        onClick={() => onOpenProductPage(prod)}
                        className="px-3 py-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl text-xs font-bold flex items-center gap-1 cursor-pointer"
                        title="Open this product page directly"
                      >
                        <ExternalLink className="w-3.5 h-3.5" />
                        <span>Open Page</span>
                      </button>

                      <button
                        type="button"
                        onClick={() => handleStartEditProduct(prod)}
                        className="p-2 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-xl cursor-pointer"
                        title="Edit product & 5 images"
                      >
                        <Edit3 className="w-4 h-4" />
                      </button>

                      <button
                        type="button"
                        onClick={() => handleDeleteProduct(prod.id)}
                        className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl cursor-pointer"
                        title="Delete product"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================
            TAB 3: MANAGE COD ORDERS
            ========================================================= */}
        {activeTab === 'orders' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-stone-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  Cash on Delivery Dispatch Queue
                </span>
                <h1 className="text-xl sm:text-2xl font-extrabold text-stone-950">
                  Manage COD Orders ({storeState.orders.length})
                </h1>
              </div>

              {/* Filter Tabs */}
              <div className="flex flex-wrap items-center gap-1 bg-stone-100 p-1 rounded-xl">
                {(
                  [
                    'ALL',
                    'Pending',
                    'Confirmed',
                    'Dispatched',
                    'Delivered',
                    'Returned',
                  ] as const
                ).map((st) => (
                  <button
                    key={st}
                    type="button"
                    onClick={() => setOrderFilter(st)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-colors cursor-pointer ${
                      orderFilter === st
                        ? 'bg-stone-950 text-white'
                        : 'text-stone-600 hover:text-stone-950'
                    }`}
                  >
                    {st}
                  </button>
                ))}
              </div>
            </div>

            {filteredOrders.length === 0 ? (
              <div className="bg-white p-10 rounded-2xl border border-stone-200 text-center text-sm text-stone-500">
                No COD orders found in &ldquo;{orderFilter}&rdquo; status.
              </div>
            ) : (
              <div className="space-y-3">
                {filteredOrders.map((ord) => {
                  const customerWaUrl = buildWhatsAppUrl(
                    ord.customerPhone,
                    `Assalam-o-Alaikum ${ord.customerName}! Your E Mart order *${ord.orderNumber}* for *${ord.productName}* (COD Total: ${formatPKR(
                      ord.totalAmount
                    )}) is currently *${ord.status}*.`
                  );
                  return (
                    <div
                      key={ord.id}
                      className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 flex flex-col lg:flex-row lg:items-center justify-between gap-4"
                    >
                      <div className="flex items-start gap-3.5">
                        <div className="w-14 h-14 rounded-xl overflow-hidden bg-stone-100 border border-stone-200 shrink-0">
                          <SafeImage
                            src={ord.productImage}
                            alt={ord.productName}
                            className="w-full h-full object-cover"
                          />
                        </div>
                        <div className="space-y-1 text-xs">
                          <div className="flex flex-wrap items-center gap-2">
                            <span className="font-mono-tabular font-extrabold text-sm text-stone-950">
                              {ord.orderNumber}
                            </span>
                            <span>·</span>
                            <span className="font-bold text-emerald-800">
                              {ord.productName} (Qty: {ord.quantity})
                            </span>
                            <span>·</span>
                            <span className="font-mono-tabular font-extrabold text-red-600">
                              COD: {formatPKR(ord.totalAmount)}
                            </span>
                          </div>

                          <div dir="auto" className="text-stone-800 font-semibold">
                            Customer: {ord.customerName} —{' '}
                            <span className="font-mono-tabular">{ord.customerPhone}</span> (
                            {ord.customerCity})
                          </div>

                          <div dir="auto" className="text-stone-600">
                            Address: {ord.customerAddress}
                          </div>

                          {ord.customerNotes && (
                            <div dir="auto" className="text-amber-800 font-medium">
                              Note: {ord.customerNotes}
                            </div>
                          )}
                        </div>
                      </div>

                      <div className="flex flex-wrap items-center gap-2 shrink-0">
                        <select
                          value={ord.status}
                          onChange={(e) =>
                            onUpdateOrderStatus(ord.id, e.target.value as OrderStatus)
                          }
                          className="px-3 py-2 rounded-xl border border-stone-300 bg-[#FAF9F6] text-xs font-extrabold text-stone-900"
                        >
                          {[
                            'Pending',
                            'Confirmed',
                            'Dispatched',
                            'Delivered',
                            'Returned',
                            'Cancelled',
                          ].map((st) => (
                            <option key={st} value={st}>
                              Status: {st}
                            </option>
                          ))}
                        </select>

                        <a
                          href={customerWaUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="px-3 py-2 bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-200 rounded-xl text-xs font-bold flex items-center gap-1.5"
                        >
                          <MessageCircle className="w-3.5 h-3.5 text-emerald-700" />
                          <span>WhatsApp Customer</span>
                        </a>

                        <button
                          type="button"
                          onClick={() => onDeleteOrder(ord.id)}
                          className="p-2 bg-red-50 hover:bg-red-100 text-red-600 rounded-xl cursor-pointer"
                          title="Delete Order"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        )}

        {/* =========================================================
            TAB 4: UPLOAD / CHANGE ALL 3 ROTATING HOMEPAGE BANNERS
            ========================================================= */}
        {activeTab === 'banners' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-stone-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  Homepage Hero Carousel
                </span>
                <h1 className="text-xl sm:text-2xl font-extrabold text-stone-950">
                  Manage 3 Rotating Homepage Banners
                </h1>
                <p className="text-xs text-stone-500">
                  Upload or change all 3 banners separately from your PC and customize their headlines.
                </p>
              </div>
              <div className="flex items-center gap-3">
                <div className="flex items-center gap-1.5 text-xs">
                  <label className="font-bold text-stone-700">Slide Speed (sec):</label>
                  <input
                    type="number"
                    min={3}
                    max={15}
                    value={settingsDraft.bannerRotationSeconds}
                    onChange={(e) =>
                      setSettingsDraft((prev) => ({
                        ...prev,
                        bannerRotationSeconds: Math.max(3, Number(e.target.value) || 5),
                      }))
                    }
                    className="w-16 px-2.5 py-1.5 bg-[#FAF9F6] border border-stone-300 rounded-lg font-mono-tabular text-center"
                  />
                </div>
                <button
                  type="button"
                  onClick={handleSaveBanners}
                  className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer"
                >
                  <Save className="w-4 h-4" />
                  <span>Save All 3 Banners</span>
                </button>
              </div>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
              {([0, 1, 2] as const).map((idx) => {
                const slide = bannersDraft[idx];
                return (
                  <div
                    key={slide.id || idx}
                    className="bg-white rounded-2xl border border-stone-200 overflow-hidden flex flex-col justify-between"
                  >
                    <div>
                      <div className="bg-stone-950 text-white px-4 py-3 flex items-center justify-between">
                        <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-400">
                          Banner Slot {idx + 1}
                        </span>
                        <label className="px-3 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-[11px] font-bold flex items-center gap-1.5 cursor-pointer">
                          <Upload className="w-3 h-3" />
                          <span>Choose Banner {idx + 1} File</span>
                          <input
                            type="file"
                            accept="image/*"
                            onChange={(e) =>
                              handleBannerFileUpload(idx, e.target.files?.[0])
                            }
                            className="hidden"
                          />
                        </label>
                      </div>

                      <div className="aspect-video w-full bg-stone-900 relative overflow-hidden">
                        <SafeImage
                          src={slide.image}
                          alt={slide.title}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="p-4 space-y-3 text-xs">
                        <div>
                          <label className="font-bold text-stone-700 block mb-1">
                            Top Kicker Text
                          </label>
                          <input
                            type="text"
                            value={slide.kicker}
                            onChange={(e) => {
                              const val = e.target.value;
                              setBannersDraft((prev) => {
                                const next = [...prev] as [
                                  BannerSlide,
                                  BannerSlide,
                                  BannerSlide
                                ];
                                next[idx] = { ...next[idx], kicker: val };
                                return next;
                              });
                            }}
                            className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-lg"
                          />
                        </div>

                        <div>
                          <label className="font-bold text-stone-700 block mb-1">
                            Banner Headline
                          </label>
                          <input
                            type="text"
                            value={slide.title}
                            onChange={(e) => {
                              const val = e.target.value;
                              setBannersDraft((prev) => {
                                const next = [...prev] as [
                                  BannerSlide,
                                  BannerSlide,
                                  BannerSlide
                                ];
                                next[idx] = { ...next[idx], title: val };
                                return next;
                              });
                            }}
                            className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-lg font-bold"
                          />
                        </div>

                        <div>
                          <label className="font-bold text-stone-700 block mb-1">
                            Subtitle Description
                          </label>
                          <textarea
                            rows={2}
                            value={slide.subtitle}
                            onChange={(e) => {
                              const val = e.target.value;
                              setBannersDraft((prev) => {
                                const next = [...prev] as [
                                  BannerSlide,
                                  BannerSlide,
                                  BannerSlide
                                ];
                                next[idx] = { ...next[idx], subtitle: val };
                                return next;
                              });
                            }}
                            className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-lg"
                          />
                        </div>

                        <div className="grid grid-cols-2 gap-2">
                          <div>
                            <label className="font-bold text-stone-700 block mb-1">
                              Deal Badge
                            </label>
                            <input
                              type="text"
                              value={slide.badgeText}
                              onChange={(e) => {
                                const val = e.target.value;
                                setBannersDraft((prev) => {
                                  const next = [...prev] as [
                                    BannerSlide,
                                    BannerSlide,
                                    BannerSlide
                                  ];
                                  next[idx] = { ...next[idx], badgeText: val };
                                  return next;
                                });
                              }}
                              className="w-full px-2.5 py-1.5 bg-[#FAF9F6] border border-stone-300 rounded-lg"
                            />
                          </div>
                          <div>
                            <label className="font-bold text-stone-700 block mb-1">
                              Button Text
                            </label>
                            <input
                              type="text"
                              value={slide.ctaText}
                              onChange={(e) => {
                                const val = e.target.value;
                                setBannersDraft((prev) => {
                                  const next = [...prev] as [
                                    BannerSlide,
                                    BannerSlide,
                                    BannerSlide
                                  ];
                                  next[idx] = { ...next[idx], ctaText: val };
                                  return next;
                                });
                              }}
                              className="w-full px-2.5 py-1.5 bg-[#FAF9F6] border border-stone-300 rounded-lg"
                            />
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="p-4 pt-0">
                      <button
                        type="button"
                        onClick={handleSaveBanners}
                        className="w-full py-2.5 bg-stone-900 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors cursor-pointer"
                      >
                        Publish Banner {idx + 1}
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* =========================================================
            TAB 5: MANAGE CIRCULAR CATEGORIES
            ========================================================= */}
        {activeTab === 'categories' && (
          <div className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-stone-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  Circular Category Navigation
                </span>
                <h1 className="text-xl sm:text-2xl font-extrabold text-stone-950">
                  Manage Store Categories ({categoriesDraft.length})
                </h1>
              </div>
              <button
                type="button"
                onClick={handleSaveCategories}
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save Categories</span>
              </button>
            </div>

            {/* Add New Category Bar */}
            <div className="bg-white p-4 sm:p-5 rounded-2xl border border-stone-200 grid grid-cols-1 sm:grid-cols-4 gap-3 items-end">
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  New Category Name
                </label>
                <input
                  type="text"
                  value={newCatName}
                  onChange={(e) => setNewCatName(e.target.value)}
                  placeholder="e.g. Perfumes / Gaming"
                  className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Subtitle
                </label>
                <input
                  type="text"
                  value={newCatSubtitle}
                  onChange={(e) => setNewCatSubtitle(e.target.value)}
                  placeholder="e.g. Luxury Scents"
                  className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl text-xs"
                />
              </div>
              <div>
                <label className="block text-xs font-bold text-stone-700 mb-1">
                  Upload Category Icon from PC
                </label>
                <label className="w-full py-2 px-3 bg-stone-100 hover:bg-stone-200 text-stone-800 border border-stone-300 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer">
                  <Upload className="w-3.5 h-3.5" />
                  <span>{newCatImage ? 'Image Selected ✓' : 'Choose Image'}</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={async (e) => {
                      const f = e.target.files?.[0];
                      if (f) {
                        const url = await readAndCompressImageFile(f, 500, 0.85);
                        setNewCatImage(url);
                      }
                    }}
                    className="hidden"
                  />
                </label>
              </div>
              <button
                type="button"
                onClick={handleAddCategory}
                className="py-2.5 px-4 bg-stone-950 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 cursor-pointer"
              >
                <Plus className="w-4 h-4" />
                <span>Add Category</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
              {categoriesDraft.map((cat) => (
                <div
                  key={cat.id}
                  className="bg-white p-4 rounded-2xl border border-stone-200 flex items-center gap-3.5"
                >
                  <div className="w-16 h-16 rounded-full overflow-hidden border-2 border-emerald-700 shrink-0">
                    <SafeImage
                      src={cat.image}
                      alt={cat.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <div className="flex-1 space-y-1.5 text-xs">
                    <input
                      type="text"
                      value={cat.name}
                      onChange={(e) => {
                        const val = e.target.value;
                        setCategoriesDraft((prev) =>
                          prev.map((c) =>
                            c.id === cat.id ? { ...c, name: val, slug: val } : c
                          )
                        );
                      }}
                      className="w-full px-2.5 py-1 bg-[#FAF9F6] border border-stone-300 rounded-lg font-bold text-stone-900"
                    />
                    <div className="flex items-center gap-2">
                      <label className="px-2.5 py-1 bg-stone-100 hover:bg-stone-200 text-stone-800 rounded-md text-[11px] font-semibold cursor-pointer inline-flex items-center gap-1">
                        <Upload className="w-3 h-3" />
                        <span>Change Photo</span>
                        <input
                          type="file"
                          accept="image/*"
                          onChange={(e) =>
                            handleCategoryImageUpload(cat.id, e.target.files?.[0])
                          }
                          className="hidden"
                        />
                      </label>
                      <button
                        type="button"
                        onClick={() => handleDeleteCategory(cat.id)}
                        className="text-red-600 hover:underline text-[11px] font-semibold cursor-pointer"
                      >
                        Delete
                      </button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* =========================================================
            TAB 6: STORE SETTINGS, LOGO, TICKER, WHATSAPP & RETURN POLICY
            ========================================================= */}
        {activeTab === 'settings' && (
          <form onSubmit={handleSaveSettingsAndPolicy} className="space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-5 rounded-2xl border border-stone-200">
              <div>
                <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700">
                  No-Code Storefront Customization
                </span>
                <h1 className="text-xl sm:text-2xl font-extrabold text-stone-950">
                  Logo, Ticker, WhatsApp & Return Policy Settings
                </h1>
              </div>
              <button
                type="submit"
                className="px-5 py-2.5 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer"
              >
                <Save className="w-4 h-4" />
                <span>Save All Store Settings</span>
              </button>
            </div>

            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Branding, E Mart Logo, Announcement Ticker & WhatsApp */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4 text-xs">
                <h2 className="text-base font-extrabold text-stone-950 border-b border-stone-100 pb-2">
                  1. E Mart Logo, Announcement Ticker & WhatsApp
                </h2>

                {/* Logo Upload */}
                <div className="p-3.5 rounded-xl bg-[#FAF9F6] border border-stone-200 flex items-center justify-between gap-4">
                  <div className="space-y-1">
                    <span className="font-bold text-stone-900 block">
                      E Mart Header Logo
                    </span>
                    <span className="text-[11px] text-stone-500 block">
                      Upload a custom logo from your PC or use the built-in E Mart emblem.
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <label className="px-3 py-2 bg-stone-900 hover:bg-emerald-700 text-white rounded-xl font-bold cursor-pointer flex items-center gap-1.5">
                      <Upload className="w-3.5 h-3.5" />
                      <span>Upload Logo</span>
                      <input
                        type="file"
                        accept="image/*"
                        onChange={(e) => handleLogoUpload(e.target.files?.[0])}
                        className="hidden"
                      />
                    </label>
                    {settingsDraft.logoUrl && (
                      <button
                        type="button"
                        onClick={() =>
                          setSettingsDraft((prev) => ({ ...prev, logoUrl: '' }))
                        }
                        className="px-2.5 py-2 bg-red-50 text-red-600 rounded-xl font-bold cursor-pointer"
                      >
                        Reset
                      </button>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">
                      Store Name
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.storeName}
                      onChange={(e) =>
                        setSettingsDraft((prev) => ({
                          ...prev,
                          storeName: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                    />
                  </div>

                  <div>
                    <label className="font-bold text-emerald-800 block mb-1">
                      WhatsApp Order Number *
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.whatsappNumber}
                      onChange={(e) =>
                        setSettingsDraft((prev) => ({
                          ...prev,
                          whatsappNumber: e.target.value,
                        }))
                      }
                      placeholder="923001234567 or 03001234567"
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-emerald-400 rounded-xl font-mono-tabular font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Moving Top Announcement / Headline Ticker Text
                  </label>
                  <textarea
                    rows={2}
                    value={settingsDraft.announcementTicker}
                    onChange={(e) =>
                      setSettingsDraft((prev) => ({
                        ...prev,
                        announcementTicker: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">
                      COD Delivery Fee (Rs.)
                    </label>
                    <input
                      type="number"
                      value={settingsDraft.codDeliveryFee}
                      onChange={(e) =>
                        setSettingsDraft((prev) => ({
                          ...prev,
                          codDeliveryFee: Number(e.target.value) || 0,
                        }))
                      }
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl font-mono-tabular"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">
                      Free Delivery Over (Rs.)
                    </label>
                    <input
                      type="number"
                      value={settingsDraft.freeDeliveryThreshold}
                      onChange={(e) =>
                        setSettingsDraft((prev) => ({
                          ...prev,
                          freeDeliveryThreshold: Number(e.target.value) || 0,
                        }))
                      }
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl font-mono-tabular"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">
                      Support Phone (Footer)
                    </label>
                    <input
                      type="text"
                      value={settingsDraft.supportPhone}
                      onChange={(e) =>
                        setSettingsDraft((prev) => ({
                          ...prev,
                          supportPhone: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl font-mono-tabular"
                    />
                  </div>
                  <div>
                    <label className="font-bold text-stone-700 block mb-1">
                      Support Email
                    </label>
                    <input
                      type="email"
                      value={settingsDraft.supportEmail}
                      onChange={(e) =>
                        setSettingsDraft((prev) => ({
                          ...prev,
                          supportEmail: e.target.value,
                        }))
                      }
                      className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                    />
                  </div>
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Store Warehouse / Office Address
                  </label>
                  <input
                    type="text"
                    value={settingsDraft.storeAddress}
                    onChange={(e) =>
                      setSettingsDraft((prev) => ({
                        ...prev,
                        storeAddress: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                  />
                </div>
              </div>

              {/* Return & Refund Policy + Admin Security */}
              <div className="bg-white p-5 rounded-2xl border border-stone-200 space-y-4 text-xs">
                <h2 className="text-base font-extrabold text-stone-950 border-b border-stone-100 pb-2">
                  2. Return & Refund Policy & Admin Security
                </h2>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Return Policy Section Heading
                  </label>
                  <input
                    type="text"
                    value={returnPolicyDraft.heading}
                    onChange={(e) =>
                      setReturnPolicyDraft((prev) => ({
                        ...prev,
                        heading: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl font-bold"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Return Policy Subheading
                  </label>
                  <input
                    type="text"
                    value={returnPolicyDraft.subheading}
                    onChange={(e) =>
                      setReturnPolicyDraft((prev) => ({
                        ...prev,
                        subheading: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1">
                    Detailed Return & Refund Policy Terms
                  </label>
                  <textarea
                    rows={4}
                    value={returnPolicyDraft.fullPolicyText}
                    onChange={(e) =>
                      setReturnPolicyDraft((prev) => ({
                        ...prev,
                        fullPolicyText: e.target.value,
                      }))
                    }
                    className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl leading-relaxed"
                  />
                </div>

                <div className="pt-3 border-t border-stone-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <h3 className="text-xs font-extrabold uppercase tracking-wider text-stone-800">
                      Change Admin Portal Password
                    </h3>
                    <button
                      type="button"
                      onClick={() => setActiveTab('password')}
                      className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                    >
                      Open Dedicated Password Manager →
                    </button>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                    <div>
                      <label className="font-bold text-stone-700 block mb-1">
                        Admin Username
                      </label>
                      <input
                        type="text"
                        value={settingsDraft.adminUsername}
                        onChange={(e) =>
                          setSettingsDraft((prev) => ({
                            ...prev,
                            adminUsername: e.target.value,
                          }))
                        }
                        className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                      />
                    </div>
                    <div>
                      <label className="font-bold text-stone-700 block mb-1">
                        New Password (optional)
                      </label>
                      <input
                        type="password"
                        value={newAdminPassword}
                        onChange={(e) => setNewAdminPassword(e.target.value)}
                        placeholder="Enter new password to change"
                        className="w-full px-3 py-2 bg-[#FAF9F6] border border-stone-300 rounded-xl"
                      />
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </form>
        )}

        {/* =========================================================
            TAB 7: DEDICATED CHANGE PASSWORD OPTION IN ADMIN PORTAL
            ========================================================= */}
        {activeTab === 'password' && (
          <div className="max-w-xl mx-auto space-y-6">
            <div className="bg-white p-6 sm:p-8 rounded-2xl border border-stone-200 shadow-xs space-y-5">
              <div className="flex items-center gap-3 border-b border-stone-100 pb-4">
                <div className="w-11 h-11 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-700 flex items-center justify-center shrink-0">
                  <Lock className="w-5 h-5" />
                </div>
                <div>
                  <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 block">
                    Admin Portal Security
                  </span>
                  <h1 className="text-xl font-extrabold text-stone-950">
                    Change Admin Portal Password
                  </h1>
                  <p className="text-xs text-stone-500">
                    Update your Admin Portal login password anytime. Your new password takes effect immediately.
                  </p>
                </div>
              </div>

              {passwordStatusMsg && (
                <div className="p-3.5 rounded-xl bg-emerald-50 border border-emerald-200 text-xs font-bold text-emerald-900 flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
                  <span>{passwordStatusMsg}</span>
                </div>
              )}

              {passwordErrorMsg && (
                <div className="p-3.5 rounded-xl bg-red-50 border border-red-200 text-xs font-bold text-red-700">
                  {passwordErrorMsg}
                </div>
              )}

              <form onSubmit={handleChangePassword} className="space-y-4 text-xs">
                <div>
                  <label className="font-bold text-stone-700 block mb-1.5">
                    Admin Username
                  </label>
                  <input
                    type="text"
                    required
                    value={settingsDraft.adminUsername}
                    onChange={(e) =>
                      setSettingsDraft((prev) => ({
                        ...prev,
                        adminUsername: e.target.value,
                      }))
                    }
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1.5">
                    Current Password (optional verification)
                  </label>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    value={currentAdminPassword}
                    onChange={(e) => setCurrentAdminPassword(e.target.value)}
                    placeholder="Enter current password (or leave blank)"
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900"
                  />
                </div>

                <div>
                  <div className="flex items-center justify-between mb-1.5">
                    <label className="font-bold text-stone-700">
                      New Strong Password *
                    </label>
                    <button
                      type="button"
                      onClick={() => setShowNewPassword((prev) => !prev)}
                      className="text-[11px] font-bold text-emerald-700 hover:underline cursor-pointer"
                    >
                      {showNewPassword ? 'Hide Passwords' : 'Show Passwords'}
                    </button>
                  </div>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={newAdminPassword}
                    onChange={(e) => setNewAdminPassword(e.target.value)}
                    placeholder="Enter new strong password"
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900"
                  />
                </div>

                <div>
                  <label className="font-bold text-stone-700 block mb-1.5">
                    Confirm New Password *
                  </label>
                  <input
                    type={showNewPassword ? 'text' : 'password'}
                    required
                    value={confirmAdminPassword}
                    onChange={(e) => setConfirmAdminPassword(e.target.value)}
                    placeholder="Re-enter new password"
                    className="w-full px-3.5 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm text-stone-900"
                  />
                </div>

                <div className="pt-2 flex items-center justify-end gap-3">
                  <button
                    type="submit"
                    className="px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl text-xs sm:text-sm font-extrabold flex items-center gap-2 cursor-pointer shadow-xs"
                  >
                    <Save className="w-4 h-4" />
                    <span>Change Password Now</span>
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};
