import React, { useState, useEffect } from 'react';
import { ShoppingBag } from 'lucide-react';

interface SafeImageProps {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
}

export const SafeImage: React.FC<SafeImageProps> = ({
  src,
  alt,
  className = 'w-full h-full object-cover',
  fallbackLabel,
}) => {
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    setHasError(false);
  }, [src]);

  if (!src || hasError) {
    return (
      <div
        className={`flex flex-col items-center justify-center bg-gradient-to-br from-stone-900 via-stone-800 to-emerald-950 text-stone-100 p-4 select-none ${className}`}
        role="img"
        aria-label={alt}
      >
        <div className="w-12 h-12 rounded-full bg-white/10 border border-white/15 flex items-center justify-center mb-2.5">
          <ShoppingBag className="w-5 h-5 text-emerald-400" />
        </div>
        <span className="text-xs font-semibold tracking-wide text-center line-clamp-2 max-w-[180px] text-white/90">
          {fallbackLabel || alt || 'E Mart Studio Verified'}
        </span>
        <span className="text-[10px] text-emerald-300/80 mt-1 font-medium">
          E Mart Original
        </span>
      </div>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      referrerPolicy="no-referrer"
      onError={() => setHasError(true)}
      className={className}
      loading="lazy"
    />
  );
};
