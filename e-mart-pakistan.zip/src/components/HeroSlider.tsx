import React, { useState, useEffect } from 'react';
import { ChevronLeft, ChevronRight, ArrowRight, ShieldCheck, Truck } from 'lucide-react';
import { BannerSlide } from '../types/store';
import { SafeImage } from './SafeImage';

interface HeroSliderProps {
  banners: [BannerSlide, BannerSlide, BannerSlide];
  rotationSeconds: number;
  onSelectCategory: (category: string) => void;
}

export const HeroSlider: React.FC<HeroSliderProps> = ({
  banners,
  rotationSeconds = 5,
  onSelectCategory,
}) => {
  const [activeIndex, setActiveIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  const safeBanners = banners && banners.length === 3 ? banners : [];

  useEffect(() => {
    if (isPaused || safeBanners.length <= 1) return;
    const ms = Math.max(3, rotationSeconds) * 1000;
    const timer = setInterval(() => {
      setActiveIndex((prev) => (prev + 1) % safeBanners.length);
    }, ms);
    return () => clearInterval(timer);
  }, [isPaused, rotationSeconds, safeBanners.length]);

  if (safeBanners.length === 0) return null;

  const currentSlide = safeBanners[activeIndex] || safeBanners[0];

  const handlePrev = () => {
    setActiveIndex((prev) => (prev - 1 + safeBanners.length) % safeBanners.length);
  };

  const handleNext = () => {
    setActiveIndex((prev) => (prev + 1) % safeBanners.length);
  };

  return (
    <section
      aria-label="Featured Promotions"
      className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 pt-3 sm:pt-5"
    >
      <div
        className="relative rounded-2xl overflow-hidden bg-stone-950 border border-stone-200/80 shadow-sm"
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
      >
        {/* Responsive Aspect Container: compact on mobile, cinematic on desktop */}
        <div className="relative h-[260px] xs:h-[290px] sm:h-[360px] md:h-[420px] lg:h-[460px] w-full">
          {safeBanners.map((slide, idx) => {
            const isActive = idx === activeIndex;
            return (
              <div
                key={slide.id || idx}
                className={`absolute inset-0 transition-opacity duration-700 ease-out ${
                  isActive ? 'opacity-100 z-10' : 'opacity-0 z-0 pointer-events-none'
                }`}
              >
                <SafeImage
                  src={slide.image}
                  alt={slide.title}
                  className="w-full h-full object-cover object-center"
                />
                {/* Measured Scrim for High-Contrast Legibility on Both Mobile & Desktop */}
                <div className="absolute inset-0 bg-gradient-to-r from-stone-950/90 via-stone-950/65 to-stone-950/20 sm:via-stone-950/50 sm:to-transparent" />
                <div className="absolute inset-0 bg-gradient-to-t from-stone-950/85 via-transparent to-stone-950/20" />
              </div>
            );
          })}

          {/* Foreground Content */}
          <div className="relative z-20 h-full flex flex-col justify-between p-4 sm:p-8 md:p-12 lg:p-14 max-w-2xl">
            <div className="space-y-2 sm:space-y-3.5 my-auto">
              {/* Top Kicker & Deal Tag */}
              <div className="flex flex-wrap items-center gap-2 text-[11px] sm:text-xs font-semibold tracking-wider text-emerald-300">
                <span>{currentSlide.kicker}</span>
                {currentSlide.badgeText && (
                  <>
                    <span aria-hidden="true" className="text-stone-400">
                      ·
                    </span>
                    <span className="text-amber-300 font-bold">{currentSlide.badgeText}</span>
                  </>
                )}
              </div>

              {/* Main Headline */}
              <h1 className="text-xl xs:text-2xl sm:text-4xl lg:text-5xl font-extrabold text-white tracking-tight leading-[1.12] [text-wrap:balance]">
                {currentSlide.title}
              </h1>

              {/* Subtitle */}
              <p className="text-xs sm:text-sm md:text-base text-stone-200/90 max-w-xl line-clamp-2 sm:line-clamp-3 leading-relaxed">
                {currentSlide.subtitle}
              </p>

              {/* Primary CTA Button */}
              <div className="pt-1.5 sm:pt-3 flex flex-wrap items-center gap-3">
                <button
                  type="button"
                  onClick={() => {
                    onSelectCategory(currentSlide.targetCategory || 'ALL');
                    const el = document.getElementById('products-grid-section');
                    if (el) el.scrollIntoView({ behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 px-4 sm:px-6 py-2.5 sm:py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs sm:text-sm font-bold rounded-xl shadow-md transition-all cursor-pointer whitespace-nowrap"
                >
                  <span>{currentSlide.ctaText || 'Shop Collection Now'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>

                <div className="hidden sm:flex items-center gap-3 text-xs text-stone-300 font-medium pl-1">
                  <span className="inline-flex items-center gap-1">
                    <Truck className="w-3.5 h-3.5 text-emerald-400" />
                    Fast COD Delivery
                  </span>
                  <span>·</span>
                  <span className="inline-flex items-center gap-1">
                    <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                    7-Day Return Policy
                  </span>
                </div>
              </div>
            </div>

            {/* Bottom Controls: 3 Slide Indicators + Prev/Next Buttons */}
            <div className="flex items-center justify-between pt-2">
              <div className="flex items-center gap-2">
                {safeBanners.map((slide, idx) => (
                  <button
                    key={slide.id || idx}
                    type="button"
                    onClick={() => setActiveIndex(idx)}
                    aria-label={`Show Banner ${idx + 1}`}
                    className={`h-1.5 rounded-full transition-all duration-300 ${
                      idx === activeIndex
                        ? 'w-8 sm:w-10 bg-emerald-400'
                        : 'w-2.5 bg-white/35 hover:bg-white/60'
                    }`}
                  />
                ))}
                <span className="ml-2 text-[11px] font-mono-tabular text-stone-300">
                  0{activeIndex + 1} / 0{safeBanners.length}
                </span>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={handlePrev}
                  aria-label="Previous Banner"
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/45 hover:bg-black/70 text-white border border-white/15 flex items-center justify-center transition-colors"
                >
                  <ChevronLeft className="w-4 h-4" />
                </button>
                <button
                  type="button"
                  onClick={handleNext}
                  aria-label="Next Banner"
                  className="w-8 h-8 sm:w-9 sm:h-9 rounded-full bg-black/45 hover:bg-black/70 text-white border border-white/15 flex items-center justify-center transition-colors"
                >
                  <ChevronRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
