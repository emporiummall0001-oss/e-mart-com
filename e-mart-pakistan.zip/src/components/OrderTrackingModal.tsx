import React, { useState } from 'react';
import { X, Search, PackageCheck, Truck, Clock, RotateCcw } from 'lucide-react';
import { CODOrder } from '../types/store';
import { formatPKR } from '../utils/helpers';

interface OrderTrackingModalProps {
  isOpen: boolean;
  orders: CODOrder[];
  onClose: () => void;
}

export const OrderTrackingModal: React.FC<OrderTrackingModalProps> = ({
  isOpen,
  orders,
  onClose,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const cleanQ = query.trim().toLowerCase();
  const matchedOrders = cleanQ
    ? orders.filter(
        (o) =>
          o.orderNumber.toLowerCase().includes(cleanQ) ||
          o.customerPhone.replace(/\D/g, '').includes(cleanQ.replace(/\D/g, '')) ||
          o.customerName.toLowerCase().includes(cleanQ)
      )
    : orders.slice(0, 3);

  return (
    <div className="fixed inset-0 z-50 bg-stone-950/65 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-2xl border border-stone-200 max-w-lg w-full overflow-hidden shadow-xl">
        <div className="bg-stone-950 text-white px-5 py-4 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-semibold uppercase tracking-wider text-emerald-400 block">
              Real-Time COD Dispatch Lookup
            </span>
            <h2 className="text-base sm:text-lg font-extrabold">
              Track Your Cash on Delivery Order
            </h2>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 rounded-lg text-stone-400 hover:text-white hover:bg-stone-800 cursor-pointer"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 max-h-[80vh] overflow-y-auto">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Enter Order ID (e.g. EM-9041) or Phone Number (0300...)"
              className="w-full pl-10 pr-4 py-2.5 bg-[#FAF9F6] border border-stone-300 rounded-xl text-sm focus:outline-none focus:bg-white focus:border-emerald-700"
              autoFocus
            />
          </div>

          <div className="space-y-2.5">
            <div className="text-xs font-semibold text-stone-500">
              {cleanQ
                ? `Matching Orders (${matchedOrders.length})`
                : 'Recent Store Orders (Sample Preview)'}
            </div>

            {matchedOrders.length === 0 ? (
              <div className="p-6 text-center rounded-xl bg-stone-50 border border-stone-200 text-xs text-stone-500">
                No order found matching &ldquo;{query}&rdquo;. Please check your Order ID (e.g., EM-9041) or mobile number.
              </div>
            ) : (
              matchedOrders.map((ord) => (
                <div
                  key={ord.id}
                  className="p-3.5 rounded-xl bg-[#FAF9F6] border border-stone-200/90 space-y-2 text-xs"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-mono-tabular font-extrabold text-stone-950 text-sm">
                      {ord.orderNumber}
                    </span>
                    <span
                      className={`inline-flex items-center gap-1 font-bold ${
                        ord.status === 'Delivered'
                          ? 'text-emerald-700'
                          : ord.status === 'Returned' || ord.status === 'Cancelled'
                          ? 'text-red-600'
                          : 'text-amber-700'
                      }`}
                    >
                      {ord.status === 'Delivered' ? (
                        <PackageCheck className="w-3.5 h-3.5" />
                      ) : ord.status === 'Returned' ? (
                        <RotateCcw className="w-3.5 h-3.5" />
                      ) : ord.status === 'Dispatched' ? (
                        <Truck className="w-3.5 h-3.5" />
                      ) : (
                        <Clock className="w-3.5 h-3.5" />
                      )}
                      {ord.status}
                    </span>
                  </div>
                  <p className="font-semibold text-stone-800 line-clamp-1">
                    {ord.productName} (x{ord.quantity})
                  </p>
                  <div className="flex items-center justify-between text-stone-500 pt-1 border-t border-stone-200/70">
                    <span dir="auto">
                      {ord.customerName} · {ord.customerCity}
                    </span>
                    <span className="font-mono-tabular font-bold text-stone-900">
                      COD: {formatPKR(ord.totalAmount)}
                    </span>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
