import React, { useState } from 'react';
import {
  Search,
  ShieldCheck,
  Menu,
  X,
  PackageSearch,
  MessageCircle,
  Sparkles,
  Users,
} from 'lucide-react';
import { CategoryItem, StoreSettings } from '../types/store';
import { buildWhatsAppUrl } from '../utils/helpers';
import { SafeImage } from './SafeImage';

interface HeaderProps {
  settings: StoreSettings;
  categories: CategoryItem[];
  activeCategory: string;
  searchQuery: string;
  liveVisitors: number;
  currentView: 'home' | 'product' | 'admin';
  onSelectCategory: (catSlug: string) => void;
  onSearchChange: (q: string) => void;
  onNavigateHome: () => void;
  onNavigateAdmin: () => void;
  onOpenTrackModal: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  settings,
  categories,
  activeCategory,
  searchQuery,
  liveVisitors,
  currentView,
  onSelectCategory,
  onSearchChange,
  onNavigateHome,
  onNavigateAdmin,
  onOpenTrackModal,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false);

  const tickerText =
    settings.announcementTicker ||
    'FREE CASH ON DELIVERY ON ORDERS OVER RS. 2,500 ACROSS PAKISTAN • 7-DAY EASY RETURN & REFUND POLICY';

  const whatsappGeneralUrl = buildWhatsAppUrl(
    settings.whatsappNumber,
    `Assalam-o-Alaikum ${settings.storeName}! I am visiting your online store and would like to inquire about your products.`
  );

  return (
    <header className="sticky top-0 z-40 bg-[#FAF9F6]/95 backdrop-blur-md border-b border-stone-200/90">
      {/* 1. Thin Moving Announcement / Headline Ticker Bar */}
      <div className="bg-stone-950 text-stone-100 h-8 sm:h-9 flex items-center justify-between overflow-hidden border-b border-stone-800">
        <div className="relative flex-1 overflow-hidden flex items-center">
          <div className="animate-ticker whitespace-nowrap flex items-center text-[11px] sm:text-xs font-medium tracking-wide">
            <span className="px-6 text-stone-200">{tickerText}</span>
            <span className="text-emerald-400 font-bold">•</span>
            <span className="px-6 text-stone-200">{tickerText}</span>
            <span className="text-emerald-400 font-bold">•</span>
            <span className="px-6 text-stone-200">{tickerText}</span>
          </div>
        </div>

        {/* Neat Live Visitor Counter in Ticker Right Corner */}
        <div
          className="shrink-0 bg-stone-900/95 border-l border-stone-800 px-2.5 sm:px-3.5 h-full flex items-center gap-1.5 text-[11px] font-mono-tabular text-emerald-300"
          title="Real-time shoppers currently browsing E Mart"
        >
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
          <Users className="w-3 h-3 text-emerald-400 hidden sm:inline" />
          <span className="font-semibold text-white">{liveVisitors}</span>
          <span className="text-stone-300 hidden xs:inline sm:inline">Live Now</span>
        </div>
      </div>

      {/* 2. Prominent E Mart Brand Bar + Search + Quick Actions */}
      <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-2.5 sm:py-3.5 flex items-center justify-between gap-3">
        {/* Mobile Menu Button */}
        <button
          type="button"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="lg:hidden p-2 -ml-1 rounded-lg text-stone-700 hover:bg-stone-200/60 transition-colors"
          aria-label="Toggle Menu"
        >
          {mobileMenuOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>

        {/* Zone 1: Prominent Professional E Mart Logo */}
        <button
          type="button"
          onClick={onNavigateHome}
          className="flex items-center gap-2.5 sm:gap-3 text-left group focus:outline-none"
        >
          {settings.logoUrl ? (
            <div className="h-9 sm:h-11 max-w-[160px] rounded-lg overflow-hidden flex items-center">
              <SafeImage
                src={settings.logoUrl}
                alt={settings.storeName}
                className="h-full w-auto object-contain"
              />
            </div>
          ) : (
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 sm:w-10 sm:h-10 rounded-xl bg-gradient-to-br from-emerald-700 via-emerald-800 to-stone-950 flex items-center justify-center shadow-sm border border-emerald-500/30 group-hover:scale-105 transition-transform">
                <span className="text-white font-extrabold text-lg sm:text-xl tracking-tighter font-serif-editorial italic pr-0.5">
                  E
                </span>
                <span className="w-1.5 h-1.5 rounded-full bg-amber-400 -mt-3" />
              </div>
              <div className="flex flex-col">
                <span className="text-xl sm:text-2xl font-extrabold tracking-tight text-stone-950 leading-none">
                  {settings.storeName || 'E Mart'}
                </span>
              </div>
            </div>
          )}
        </button>

        {/* Zone 2: Desktop Search Input */}
        <div className="hidden md:flex flex-1 max-w-md mx-4">
          <div className="relative w-full">
            <Search className="w-4 h-4 text-stone-400 absolute left-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (currentView !== 'home') onNavigateHome();
              }}
              placeholder="Search Cosmetics, AirPods, Smart Watches, Tripods..."
              className="w-full pl-10 pr-8 py-2 bg-white border border-stone-200/90 rounded-lg text-sm text-stone-900 placeholder:text-stone-400 focus:outline-none focus:border-emerald-700 focus:ring-2 focus:ring-emerald-700/15 transition-all"
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-400 hover:text-stone-700"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
        </div>

        {/* Zone 3: Primary Store Actions */}
        <div className="flex items-center gap-1.5 sm:gap-2.5">
          {/* Mobile Search Toggle */}
          <button
            type="button"
            onClick={() => setMobileSearchOpen(!mobileSearchOpen)}
            className="md:hidden p-2 rounded-lg text-stone-700 hover:bg-stone-200/60 transition-colors"
            aria-label="Search Products"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Track COD Order Button */}
          <button
            type="button"
            onClick={onOpenTrackModal}
            className="hidden sm:inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-stone-700 hover:text-stone-950 bg-stone-100 hover:bg-stone-200/80 rounded-lg transition-colors whitespace-nowrap"
          >
            <PackageSearch className="w-3.5 h-3.5 text-emerald-700" />
            <span>Track Order</span>
          </button>

          {/* Direct WhatsApp Support Link */}
          <a
            href={whatsappGeneralUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-emerald-900 bg-emerald-50 hover:bg-emerald-100 border border-emerald-200 rounded-lg transition-colors whitespace-nowrap"
          >
            <MessageCircle className="w-3.5 h-3.5 text-emerald-700" />
            <span className="hidden sm:inline">WhatsApp</span>
          </a>

          {/* Admin Icon Button */}
          <button
            type="button"
            onClick={onNavigateAdmin}
            title="Admin Login"
            aria-label="Admin Login"
            className={`inline-flex items-center justify-center w-9 h-9 rounded-lg transition-colors shrink-0 cursor-pointer ${
              currentView === 'admin'
                ? 'bg-emerald-700 text-white shadow-sm'
                : 'bg-stone-900 text-white hover:bg-stone-800'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Mobile Expandable Search Bar */}
      {mobileSearchOpen && (
        <div className="md:hidden px-3 pb-2.5 border-t border-stone-200/60 pt-2 bg-[#FAF9F6]">
          <div className="relative">
            <Search className="w-4 h-4 text-stone-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => {
                onSearchChange(e.target.value);
                if (currentView !== 'home') onNavigateHome();
              }}
              placeholder="Search products in E Mart..."
              className="w-full pl-9 pr-8 py-2 bg-white border border-stone-300 rounded-lg text-sm focus:outline-none focus:border-emerald-700"
              autoFocus
            />
            {searchQuery && (
              <button
                type="button"
                onClick={() => onSearchChange('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-stone-500"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* 3. Thin Bordered Navigation Area with Home & Categories */}
      <nav
        aria-label="Primary Categories Navigation"
        className="border-t border-stone-200/90 bg-white/90"
      >
        <div className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 flex items-center justify-between h-10 overflow-x-auto no-scrollbar">
          <div className="flex items-center gap-1 sm:gap-2">
            <button
              type="button"
              onClick={() => {
                onSelectCategory('ALL');
                onNavigateHome();
              }}
              className={`px-3 py-1 text-xs sm:text-[13px] font-semibold rounded-md transition-colors whitespace-nowrap shrink-0 ${
                currentView === 'home' && activeCategory === 'ALL'
                  ? 'bg-stone-900 text-white'
                  : 'text-stone-700 hover:text-stone-950 hover:bg-stone-100'
              }`}
            >
              Home
            </button>

            <span className="text-stone-300 text-xs select-none">|</span>

            {categories.map((cat) => {
              const isSelected = currentView === 'home' && activeCategory === cat.slug;
              return (
                <button
                  key={cat.id}
                  type="button"
                  onClick={() => {
                    onSelectCategory(cat.slug);
                    onNavigateHome();
                  }}
                  className={`px-3 py-1 text-xs sm:text-[13px] font-medium rounded-md transition-colors whitespace-nowrap shrink-0 ${
                    isSelected
                      ? 'bg-emerald-700 text-white font-semibold'
                      : 'text-stone-600 hover:text-stone-950 hover:bg-stone-100'
                  }`}
                >
                  {cat.name}
                </button>
              );
            })}
          </div>

          <div className="hidden lg:flex items-center gap-4 text-xs text-stone-500 shrink-0 pl-4">
            <span className="inline-flex items-center gap-1 text-emerald-800 font-medium">
              <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
              Cash on Delivery All Across Pakistan
            </span>
          </div>
        </div>
      </nav>

      {/* Mobile Drawer Navigation */}
      {mobileMenuOpen && (
        <div className="lg:hidden bg-white border-b border-stone-200 px-4 py-3 space-y-2 shadow-lg">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-stone-400 px-2">
            Store Navigation & Categories
          </div>
          <div className="grid grid-cols-2 gap-1.5">
            <button
              type="button"
              onClick={() => {
                onSelectCategory('ALL');
                onNavigateHome();
                setMobileMenuOpen(false);
              }}
              className={`px-3 py-2 text-left text-xs font-semibold rounded-lg ${
                activeCategory === 'ALL' && currentView === 'home'
                  ? 'bg-stone-900 text-white'
                  : 'bg-stone-100 text-stone-800'
              }`}
            >
              All Products (Home)
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                type="button"
                onClick={() => {
                  onSelectCategory(cat.slug);
                  onNavigateHome();
                  setMobileMenuOpen(false);
                }}
                className={`px-3 py-2 text-left text-xs font-semibold rounded-lg truncate ${
                  activeCategory === cat.slug && currentView === 'home'
                    ? 'bg-emerald-700 text-white'
                    : 'bg-stone-100 text-stone-800'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
          <div className="pt-2 border-t border-stone-100 flex items-center justify-between gap-2">
            <button
              type="button"
              onClick={() => {
                onOpenTrackModal();
                setMobileMenuOpen(false);
              }}
              className="flex-1 py-2 px-3 bg-stone-100 text-stone-800 rounded-lg text-xs font-semibold flex items-center justify-center gap-1.5"
            >
              <PackageSearch className="w-3.5 h-3.5 text-emerald-700" />
              Track COD Order
            </button>
            <button
              type="button"
              onClick={() => {
                onNavigateAdmin();
                setMobileMenuOpen(false);
              }}
              title="Admin Login"
              aria-label="Admin Login"
              className="py-2 px-3 bg-stone-900 text-white rounded-lg text-xs font-semibold flex items-center justify-center"
            >
              <ShieldCheck className="w-4 h-4" />
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
