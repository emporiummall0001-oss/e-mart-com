export type StockStatus = 'in_stock' | 'low_stock' | 'out_of_stock';

export type OrderStatus = 'Pending' | 'Confirmed' | 'Dispatched' | 'Delivered' | 'Returned' | 'Cancelled';

export interface Product {
  id: string;
  slug: string;
  name: string;
  category: string;
  description: string;
  price: number;
  oldPrice: number;
  discountBadge: string;
  stockStatus: StockStatus;
  stockCount: number;
  rating: number;
  reviewsCount: number;
  images: [string, string, string, string, string];
  featured?: boolean;
  createdAt: string;
}

export interface BannerSlide {
  id: string;
  slotNumber: 1 | 2 | 3;
  image: string;
  kicker: string;
  title: string;
  subtitle: string;
  ctaText: string;
  targetCategory: string;
  badgeText: string;
}

export interface CategoryItem {
  id: string;
  name: string;
  slug: string;
  subtitle: string;
  image: string;
}

export interface CODOrder {
  id: string;
  orderNumber: string;
  productId: string;
  productName: string;
  productSlug: string;
  productImage: string;
  unitPrice: number;
  quantity: number;
  deliveryFee: number;
  totalAmount: number;
  customerName: string;
  customerPhone: string;
  customerCity: string;
  customerAddress: string;
  customerNotes: string;
  status: OrderStatus;
  createdAt: string;
}

export interface ReturnPolicyContent {
  heading: string;
  subheading: string;
  highlights: {
    title: string;
    description: string;
  }[];
  fullPolicyText: string;
  exchangeWindowDays: number;
}

export interface VisitorStats {
  liveVisitors: number;
  todayVisitors: number;
  totalVisitors: number;
  weeklyTraffic: {
    day: string;
    visitors: number;
    orders: number;
    sales: number;
  }[];
}

export interface DemoStatsBaseline {
  enabled: boolean;
  extraTotalOrders: number;
  extraDeliveredOrders: number;
  extraReturnedOrders: number;
  extraPendingOrders: number;
  extraSalesAmount: number;
}

export interface StoreSettings {
  storeName: string;
  storeTagline: string;
  logoUrl: string;
  announcementTicker: string;
  whatsappNumber: string;
  supportPhone: string;
  supportEmail: string;
  storeAddress: string;
  codDeliveryFee: number;
  freeDeliveryThreshold: number;
  bannerRotationSeconds: number;
  footerAboutText: string;
  adminUsername: string;
  adminPassword?: string;
}

export interface StoreState {
  updatedAt?: number;
  settings: StoreSettings;
  banners: [BannerSlide, BannerSlide, BannerSlide];
  categories: CategoryItem[];
  products: Product[];
  orders: CODOrder[];
  returnPolicy: ReturnPolicyContent;
  visitorStats: VisitorStats;
  demoBaseline: DemoStatsBaseline;
}
