import { StoreState } from '../types/store';

// Helper to create crisp studio angle SVG data URIs so every product has 5 distinct, unbroken gallery views out-of-the-box
function createStudioAngleSvg(
  title: string,
  angleLabel: string,
  specDetail: string,
  bgHex: string,
  accentHex: string
): string {
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 800" width="800" height="800">
    <defs>
      <radialGradient id="grad" cx="50%" cy="40%" r="65%">
        <stop offset="0%" stop-color="#ffffff" stop-opacity="0.18"/>
        <stop offset="100%" stop-color="${bgHex}" stop-opacity="1"/>
      </radialGradient>
      <linearGradient id="accentGrad" x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stop-color="${accentHex}" stop-opacity="0.9"/>
        <stop offset="100%" stop-color="${accentHex}" stop-opacity="0.4"/>
      </linearGradient>
    </defs>
    <rect width="800" height="800" fill="${bgHex}"/>
    <rect width="800" height="800" fill="url(#grad)"/>
    <circle cx="400" cy="360" r="210" fill="none" stroke="${accentHex}" stroke-opacity="0.25" stroke-width="2" stroke-dasharray="8 8"/>
    <circle cx="400" cy="360" r="150" fill="url(#accentGrad)" fill-opacity="0.15" stroke="${accentHex}" stroke-opacity="0.45" stroke-width="2"/>
    <rect x="260" y="250" width="280" height="220" rx="28" fill="#18181B" fill-opacity="0.55" stroke="#ffffff" stroke-opacity="0.2" stroke-width="2"/>
    <text x="400" y="335" text-anchor="middle" fill="#FFFFFF" font-family="Plus Jakarta Sans, sans-serif" font-size="22" font-weight="700" letter-spacing="2">${angleLabel.toUpperCase()}</text>
    <text x="400" y="375" text-anchor="middle" fill="${accentHex}" font-family="Plus Jakarta Sans, sans-serif" font-size="18" font-weight="600">${specDetail}</text>
    <text x="400" y="420" text-anchor="middle" fill="#E4E4E7" font-family="Plus Jakarta Sans, sans-serif" font-size="15" font-weight="500">E MART ORIGINAL VERIFIED</text>
    <rect x="120" y="610" width="560" height="96" rx="16" fill="#09090B" fill-opacity="0.68" stroke="#ffffff" stroke-opacity="0.12" stroke-width="1.5"/>
    <text x="400" y="652" text-anchor="middle" fill="#FFFFFF" font-family="Plus Jakarta Sans, sans-serif" font-size="22" font-weight="700">${title}</text>
    <text x="400" y="684" text-anchor="middle" fill="#A1A1AA" font-family="Plus Jakarta Sans, sans-serif" font-size="15" font-weight="500">100% Parcel Inspection Allowed · 7-Day Warranty</text>
  </svg>`;
  return `data:image/svg+xml;utf8,${encodeURIComponent(svg)}`;
}

const IMG_BANNER_1 = '/src/assets/images/banner_tech_audio_1790774495750.jpg';
const IMG_BANNER_2 = '/src/assets/images/banner_beauty_cosmetics_1790774513207.jpg';
const IMG_BANNER_3 = '/src/assets/images/banner_creator_gear_1790774528217.jpg';

const IMG_COSMETICS = '/src/assets/images/prod_cosmetics_set_1790774542490.jpg';
const IMG_AIRPODS = '/src/assets/images/prod_airpods_pro_1790774556900.jpg';
const IMG_HEADPHONES = '/src/assets/images/prod_headphones_anc_1790774571801.jpg';
const IMG_TRIPOD = '/src/assets/images/prod_tripod_stand_1790774586220.jpg';
const IMG_SMARTWATCH = '/src/assets/images/prod_smartwatch_ultra_1790774600499.jpg';

export const initialStoreData: StoreState = {
  settings: {
    storeName: 'E Mart',
    storeTagline: 'Pakistan’s Trusted Lifestyle & Tech Store',
    logoUrl: '',
    announcementTicker:
      'FREE CASH ON DELIVERY ON ORDERS OVER RS. 2,500 ACROSS PAKISTAN  •  OPEN PARCEL BEFORE PAYMENT IN KARACHI, LAHORE & ISLAMABAD  •  7-DAY EASY RETURN & REPLACEMENT GUARANTEE  •  FAST WHATSAPP ORDER SUPPORT: +92 300 8492026',
    whatsappNumber: '923008492026',
    supportPhone: '+92 300 8492026',
    supportEmail: 'support@emartpakistan.pk',
    storeAddress: 'Plot 14-C, Commercial Area, Gulberg III, Lahore, Pakistan',
    codDeliveryFee: 200,
    freeDeliveryThreshold: 2500,
    bannerRotationSeconds: 5,
    footerAboutText:
      'E Mart brings 100% quality-checked Cosmetics, AirPods & Wireless Earbuds, Studio Headphones, Creator Tripods, and AMOLED Smart Watches straight to your doorstep anywhere in Pakistan with Cash on Delivery.',
    adminUsername: 'admin',
  },
  banners: [
    {
      id: 'banner-1',
      slotNumber: 1,
      image: IMG_BANNER_1,
      kicker: 'PAKISTAN MEGA TECH SALE',
      title: 'Next-Gen Audio & Smart Wearables',
      subtitle:
        'Experience studio-grade Active Noise Cancellation AirPods, Over-Ear Headphones, and Ultra AMOLED Smart Watches with nationwide Cash on Delivery.',
      ctaText: 'Explore Audio & Watches',
      targetCategory: 'AirPods/Earbuds',
      badgeText: 'UP TO 45% OFF TODAY',
    },
    {
      id: 'banner-2',
      slotNumber: 2,
      image: IMG_BANNER_2,
      kicker: 'LUXURY BEAUTY & SKINCARE EDITION',
      title: 'Radiant Glow Cosmetics & Serums',
      subtitle:
        'Dermatologically tested Vitamin C Glow Serums, Velvet Matte Lip Kits, and Organic Hydration Bundles crafted for Pakistani skin tones.',
      ctaText: 'Shop Cosmetics Collection',
      targetCategory: 'Cosmetics',
      badgeText: 'BUY 1 GET FREE GIFT',
    },
    {
      id: 'banner-3',
      slotNumber: 3,
      image: IMG_BANNER_3,
      kicker: 'PRO CONTENT CREATOR STUDIO GEAR',
      title: 'Professional Tripods & Ring Lights',
      subtitle:
        'Heavy-duty aluminum telescopic tripods, Bluetooth remote shutters, and 360° gimbal stabilizers built for reels, vlogs, and studio shoots.',
      ctaText: 'Shop Pro Tripods',
      targetCategory: 'Tripods',
      badgeText: 'FREE DELIVERY NATIONWIDE',
    },
  ],
  categories: [
    {
      id: 'cat-cosmetics',
      name: 'Cosmetics',
      slug: 'Cosmetics',
      subtitle: 'Serums & Beauty Kits',
      image: IMG_COSMETICS,
    },
    {
      id: 'cat-airpods',
      name: 'AirPods/Earbuds',
      slug: 'AirPods/Earbuds',
      subtitle: 'ANC Wireless Audio',
      image: IMG_AIRPODS,
    },
    {
      id: 'cat-headphones',
      name: 'Headphones',
      slug: 'Headphones',
      subtitle: 'Studio Bass & Gaming',
      image: IMG_HEADPHONES,
    },
    {
      id: 'cat-tripods',
      name: 'Tripods',
      slug: 'Tripods',
      subtitle: 'Stands & Ring Lights',
      image: IMG_TRIPOD,
    },
    {
      id: 'cat-smartwatches',
      name: 'Smart Watches',
      slug: 'Smart Watches',
      subtitle: 'AMOLED Bluetooth Call',
      image: IMG_SMARTWATCH,
    },
  ],
  products: [
    {
      id: 'prod-1',
      slug: 'airpods-pro-2nd-gen-anc-type-c',
      name: 'AirPods Pro 2nd Gen (Type-C) Active Noise Cancellation with MagSafe Case',
      category: 'AirPods/Earbuds',
      description:
        'Master Copy 1:1 Super Clone AirPods Pro 2nd Generation with working Active Noise Cancellation (ANC) and Transparency Mode. Features touch volume swipe control on stem, spatial bass audio, pop-up window animation, in-ear detection sensor, buzzer find-my-case speaker, and 30-hour total battery life with braided Type-C cable included. بہترین ساؤنڈ کوالٹی اور ایکٹیو نوائز کینسلیشن کے ساتھ پورے پاکستان میں کیش آن ڈیلیوری دستیاب ہے۔',
      price: 3499,
      oldPrice: 6500,
      discountBadge: '46% OFF DEAL',
      stockStatus: 'in_stock',
      stockCount: 42,
      rating: 4.9,
      reviewsCount: 318,
      images: [
        IMG_AIRPODS,
        IMG_BANNER_1,
        createStudioAngleSvg('AirPods Pro 2nd Gen ANC', 'View 03 · Acoustic Drivers', '45dB Active Noise Cancellation + Transparency', '#18181B', '#10B981'),
        createStudioAngleSvg('AirPods Pro 2nd Gen ANC', 'View 04 · MagSafe Charging Case', 'Type-C Fast Charge · 30 Hours Playback', '#1E293B', '#38BDF8'),
        createStudioAngleSvg('AirPods Pro 2nd Gen ANC', 'View 05 · Box Contents', '4x Silicone Ear Tips (XS/S/M/L) + Braided Cable', '#0F172A', '#A7F3D0'),
      ],
      featured: true,
      createdAt: '2026-09-20T10:00:00Z',
    },
    {
      id: 'prod-2',
      slug: 'luxe-vitamin-c-24k-glow-cosmetics-kit',
      name: 'Luxe Glow 3-in-1 Facial Kit: 20% Vitamin C Serum, Velvet Matte Lip & Hydra Cream',
      category: 'Cosmetics',
      description:
        'Complete luxury skincare and daily glam set formulated for humid & dry Pakistani weather. Includes 30ml Cold-Pressed Vitamin C + Hyaluronic Brightening Dropper Serum, 24-Hour Transfer-Proof Rosewood Velvet Matte Lipstick, and 50g Ceramide Barrier Repair Night Cream. Paraben-free, cruelty-free, and suitable for all skin types. چہرے کی قدرتی چمک اور خوبصورتی کے لیے بہترین سکن کیئر سیٹ۔',
      price: 2799,
      oldPrice: 4800,
      discountBadge: '42% OFF SALE',
      stockStatus: 'in_stock',
      stockCount: 35,
      rating: 5.0,
      reviewsCount: 246,
      images: [
        IMG_COSMETICS,
        IMG_BANNER_2,
        createStudioAngleSvg('Luxe Glow 3-in-1 Beauty Kit', 'View 03 · Active Ingredients', '20% L-Ascorbic Vitamin C + Botanical Hyaluronic', '#2E1F18', '#F59E0B'),
        createStudioAngleSvg('Luxe Glow 3-in-1 Beauty Kit', 'View 04 · Texture & Finish', 'Non-Greasy Fast Absorption · Velvet Matte Tint', '#3B231A', '#FBBF24'),
        createStudioAngleSvg('Luxe Glow 3-in-1 Beauty Kit', 'View 05 · Dermatologist Tested', '100% Original Sealed Packaging · Halal Certified', '#1C1917', '#FDE68A'),
      ],
      featured: true,
      createdAt: '2026-09-21T11:30:00Z',
    },
    {
      id: 'prod-3',
      slug: 'ultra-9-pro-amoled-titanium-smart-watch',
      name: 'Watch Ultra 9 Pro Max 49mm Super AMOLED Display with 3 Straps & Wireless Charger',
      category: 'Smart Watches',
      description:
        'True 2.12-inch Always-On Super AMOLED display with 90Hz smooth refresh rate and titanium alloy casing. Make and receive crystal-clear Bluetooth calls directly from your wrist, read WhatsApp & SMS notifications, track heart rate, SpO2, steps, and prayer times. Comes with 3 interchangeable straps (Ocean Silicone, Alpine Loop & Metallic Link). واٹس ایپ نوٹیفکیشن اور بلوٹوتھ کالنگ کے ساتھ بہترین سمارٹ واچ۔',
      price: 4299,
      oldPrice: 7500,
      discountBadge: '43% OFF HOT',
      stockStatus: 'in_stock',
      stockCount: 29,
      rating: 4.9,
      reviewsCount: 412,
      images: [
        IMG_SMARTWATCH,
        IMG_BANNER_1,
        createStudioAngleSvg('Watch Ultra 9 Pro Max', 'View 03 · Super AMOLED Screen', '2.12" Always-On Retina Display · 1000 Nits', '#0F172A', '#F97316'),
        createStudioAngleSvg('Watch Ultra 9 Pro Max', 'View 04 · 3 Free Straps Included', 'Ocean Band + Alpine Loop + Titanium Style Strap', '#18181B', '#10B981'),
        createStudioAngleSvg('Watch Ultra 9 Pro Max', 'View 05 · Health & Call Suite', 'Bluetooth Calling · IP68 Water Resistant · 5-Day Battery', '#1E1B4B', '#60A5FA'),
      ],
      featured: true,
      createdAt: '2026-09-22T09:15:00Z',
    },
    {
      id: 'prod-4',
      slug: 'studio-pro-max-anc-wireless-headphones',
      name: 'Studio Pro Max Over-Ear Wireless ANC Headphones — Champagne Gold & Matte Black',
      category: 'Headphones',
      description:
        'Audiophile 40mm Neodymium dynamic drivers deliver deep punchy bass and crisp vocal clarity. Ultra-soft memory foam protein leather ear cushions provide all-day comfort for university, office, gaming, and travel. Supports Bluetooth 5.3, AUX 3.5mm wired mode, TF card slot, and 45 hours of continuous playtime on a single charge.',
      price: 3899,
      oldPrice: 6999,
      discountBadge: '44% OFF DEAL',
      stockStatus: 'in_stock',
      stockCount: 24,
      rating: 4.8,
      reviewsCount: 189,
      images: [
        IMG_HEADPHONES,
        IMG_BANNER_1,
        createStudioAngleSvg('Studio Pro Max Headphones', 'View 03 · 40mm Bass Drivers', 'Hi-Res Spatial Audio + Deep Bass Boost Mode', '#18181B', '#EAB308'),
        createStudioAngleSvg('Studio Pro Max Headphones', 'View 04 · Memory Foam Cushions', 'Breathable Protein Leather · Foldable Travel Design', '#27272A', '#FACC15'),
        createStudioAngleSvg('Studio Pro Max Headphones', 'View 05 · Dual Mode Connectivity', 'Bluetooth 5.3 Wireless + 3.5mm AUX Audio Cable', '#09090B', '#A3E635'),
      ],
      featured: true,
      createdAt: '2026-09-23T14:20:00Z',
    },
    {
      id: 'prod-5',
      slug: 'pro-creator-7ft-aluminum-tripod-ring-light',
      name: 'Pro Creator 7-Foot Heavy Duty Aluminum Tripod Stand with Bluetooth Remote & Phone Holder',
      category: 'Tripods',
      description:
        'Engineered from anodized aircraft-grade aluminum alloy for zero-wobble stability indoors and outdoors. Extends from 22 inches up to a full 84 inches (7 feet) with 360-degree fluid pan head, universal spring-loaded smartphone clamp, 1/4" DSLR & ring-light screw mount, and detachable rechargeable Bluetooth shutter remote for TikTok, YouTube & family photography.',
      price: 2499,
      oldPrice: 4200,
      discountBadge: '40% OFF DEAL',
      stockStatus: 'in_stock',
      stockCount: 50,
      rating: 4.9,
      reviewsCount: 274,
      images: [
        IMG_TRIPOD,
        IMG_BANNER_3,
        createStudioAngleSvg('Pro Creator 7Ft Tripod', 'View 03 · 360° Panorama Ball Head', 'Vertical & Horizontal Lock for Reels & YouTube', '#18181B', '#10B981'),
        createStudioAngleSvg('Pro Creator 7Ft Tripod', 'View 04 · Bluetooth Remote Shutter', '10m Wireless Range for iOS & Android Phones', '#1E293B', '#38BDF8'),
        createStudioAngleSvg('Pro Creator 7Ft Tripod', 'View 05 · Carry Bag Included', 'Folds to 55cm · Supports Phones, Ring Lights & DSLRs', '#0F172A', '#34D399'),
      ],
      featured: true,
      createdAt: '2026-09-24T16:00:00Z',
    },
    {
      id: 'prod-6',
      slug: 'galaxy-buds-3-pro-ai-anc-earbuds',
      name: 'Buds 3 Pro Blade LED Wireless Earbuds with Dual-Amp Hi-Fi Sound & ENC Mic',
      category: 'AirPods/Earbuds',
      description:
        'Futuristic transparent smoky lid charging case with iconic Blade LED light strip on the stems. Equipped with Quad-Mic Environmental Noise Cancellation (ENC) for crystal-clear calls on motorbike or busy streets, low-latency 45ms PUBG gaming mode, and IPX5 sweat resistance.',
      price: 3199,
      oldPrice: 5500,
      discountBadge: '42% OFF SALE',
      stockStatus: 'in_stock',
      stockCount: 19,
      rating: 4.8,
      reviewsCount: 142,
      images: [
        IMG_AIRPODS,
        IMG_BANNER_1,
        createStudioAngleSvg('Buds 3 Pro Blade LED', 'View 03 · Quad-Mic Call Clarity', 'AI Wind & Traffic Noise Reduction for Calls', '#111827', '#60A5FA'),
        createStudioAngleSvg('Buds 3 Pro Blade LED', 'View 04 · 45ms Gaming Mode', 'Zero Audio Lag for PUBG & FreeFire', '#1F2937', '#34D399'),
        createStudioAngleSvg('Buds 3 Pro Blade LED', 'View 05 · Type-C Rapid Charge', '10 Mins Charge = 150 Mins Playtime', '#0F172A', '#A78BFA'),
      ],
      featured: false,
      createdAt: '2026-09-25T12:00:00Z',
    },
    {
      id: 'prod-7',
      slug: 'rose-gold-collagen-flawless-bridal-makeup-bundle',
      name: 'Rose Gold Flawless Bridal & Party Glow Bundle (Foundation + Niacinamide + Lip Tint)',
      category: 'Cosmetics',
      description:
        'All-in-one waterproof HD full-coverage foundation, 10% Niacinamide Pore Minimizing Glow Drops, and Berry Rose Cheek & Lip Stain. Designed for 16-hour sweat-resistant wear with SPF 30 sun protection and luminous glass-skin finish.',
      price: 3299,
      oldPrice: 5800,
      discountBadge: '43% OFF BRIDAL DEAL',
      stockStatus: 'low_stock',
      stockCount: 8,
      rating: 4.9,
      reviewsCount: 195,
      images: [
        IMG_COSMETICS,
        IMG_BANNER_2,
        createStudioAngleSvg('Rose Gold Flawless Bundle', 'View 03 · HD Waterproof Coverage', 'SPF 30 Protection · No White Cast or Oxidation', '#3B1D2E', '#F472B6'),
        createStudioAngleSvg('Rose Gold Flawless Bundle', 'View 04 · 10% Niacinamide Serum', 'Minimizes Pores & Dark Spots in 14 Days', '#2E1824', '#FB7185'),
        createStudioAngleSvg('Rose Gold Flawless Bundle', 'View 05 · Gift Ready Box', 'Luxury Magnetic Box · Sealed Authenticity', '#1F1219', '#FBBF24'),
      ],
      featured: false,
      createdAt: '2026-09-26T10:00:00Z',
    },
    {
      id: 'prod-8',
      slug: 'series-10-curved-edge-amoled-smartwatch',
      name: 'Series 10 Slim 46mm Jet Black Curved AMOLED Smart Watch with Gesture Control',
      category: 'Smart Watches',
      description:
        'Ultra-thin 9.7mm sleek aluminum body with edge-to-edge curved OLED display. Double-tap finger gesture to answer calls, built-in voice assistant, dynamic island notifications, compass, calculator, and magnetic fast charging puck.',
      price: 3999,
      oldPrice: 6800,
      discountBadge: '41% OFF DEAL',
      stockStatus: 'in_stock',
      stockCount: 31,
      rating: 4.9,
      reviewsCount: 228,
      images: [
        IMG_SMARTWATCH,
        IMG_BANNER_3,
        createStudioAngleSvg('Series 10 Slim 46mm Watch', 'View 03 · Double-Tap Gesture', 'Answer Calls & Scroll Without Touching Screen', '#09090B', '#38BDF8'),
        createStudioAngleSvg('Series 10 Slim 46mm Watch', 'View 04 · Ultra-Thin 9.7mm Profile', 'Jet Black Polished Alloy · Crown Haptic Feedback', '#18181B', '#10B981'),
        createStudioAngleSvg('Series 10 Slim 46mm Watch', 'View 05 · 100+ Custom Watch Faces', 'Upload Your Own Wallpaper via Mobile App', '#1E293B', '#F59E0B'),
      ],
      featured: false,
      createdAt: '2026-09-26T15:00:00Z',
    },
    {
      id: 'prod-9',
      slug: 'auto-face-tracking-360-gimbal-tripod-stand',
      name: '360° AI Auto Face-Tracking Smart Tripod Gimbal with Detachable Fill Light',
      category: 'Tripods',
      description:
        'Smart AI optical sensor automatically rotates 360 degrees to follow your face and movement during live streams, cooking videos, makeup tutorials, or online classes—no app required! Includes gesture recognition (OK sign to start tracking, Palm to pause) and standard 1/4" tripod thread.',
      price: 3699,
      oldPrice: 6200,
      discountBadge: '40% OFF CREATOR',
      stockStatus: 'in_stock',
      stockCount: 17,
      rating: 4.8,
      reviewsCount: 163,
      images: [
        IMG_TRIPOD,
        IMG_BANNER_3,
        createStudioAngleSvg('360° AI Face-Tracking Tripod', 'View 03 · Smart Gesture Control', 'Show 👌 Gesture to Track · Show ✋ to Pause', '#18181B', '#10B981'),
        createStudioAngleSvg('360° AI Face-Tracking Tripod', 'View 04 · No App Required', 'Works Directly with TikTok, Instagram, Zoom & Camera', '#0F172A', '#38BDF8'),
        createStudioAngleSvg('360° AI Face-Tracking Tripod', 'View 05 · Rechargeable Battery', 'Built-in 2200mAh Lithium Battery · 8 Hours Use', '#1E293B', '#F59E0B'),
      ],
      featured: false,
      createdAt: '2026-09-27T11:00:00Z',
    },
    {
      id: 'prod-10',
      slug: 'hyperbass-rgb-gaming-studio-headset',
      name: 'HyperBass Pro 7.1 Surround Wireless & Wired Studio Headset with Detachable Boom Mic',
      category: 'Headphones',
      description:
        'Engineered for both pro gaming and music production. Dual-wireless 2.4GHz dongle + Bluetooth 5.3 + 3.5mm wired connection. Features 50mm titanium-coated acoustic drivers, detachable noise-cancelling boom microphone, and plush cooling-gel ear pads.',
      price: 4499,
      oldPrice: 7800,
      discountBadge: '42% OFF PRO',
      stockStatus: 'in_stock',
      stockCount: 21,
      rating: 4.9,
      reviewsCount: 154,
      images: [
        IMG_HEADPHONES,
        IMG_BANNER_1,
        createStudioAngleSvg('HyperBass Pro 7.1 Headset', 'View 03 · 50mm Titanium Drivers', 'Pinpoint Footstep Accuracy & Studio Bass', '#18181B', '#EC4899'),
        createStudioAngleSvg('HyperBass Pro 7.1 Headset', 'View 04 · Detachable ENC Boom Mic', 'Crystal Clear Voice Chat + Mute Toggle Switch', '#0F172A', '#38BDF8'),
        createStudioAngleSvg('HyperBass Pro 7.1 Headset', 'View 05 · Cooling-Gel Ear Pads', 'Zero Ear Fatigue During Long Sessions', '#1E293B', '#10B981'),
      ],
      featured: false,
      createdAt: '2026-09-28T09:00:00Z',
    },
  ],
  orders: [],
  returnPolicy: {
    heading: '7-Day Easy Return, Refund & Parcel Inspection Policy',
    subheading:
      'Shop with 100% confidence at E Mart Pakistan. Every parcel is backed by our hassle-free 7-day replacement and money-back guarantee.',
    exchangeWindowDays: 7,
    highlights: [
      {
        title: 'Open Parcel / Video Verification',
        description:
          'Record a short parcel-opening video upon receiving your Cash on Delivery package so any transit damage or missing accessory is replaced immediately at zero cost.',
      },
      {
        title: '7-Day Instant Replacement & Refund',
        description:
          'If you receive a defective, damaged, or wrong item, notify us on WhatsApp within 7 days of delivery for a free doorstep exchange or full refund.',
      },
      {
        title: 'Fast Refund via JazzCash, EasyPaisa or Bank',
        description:
          'Approved refunds are transferred directly to your JazzCash, EasyPaisa, SadaPay, NayaPay, or Pakistani Bank Account within 24–48 business hours.',
      },
    ],
    fullPolicyText:
      'At E Mart Pakistan, customer trust is our highest priority. All Cosmetics, AirPods/Earbuds, Headphones, Tripods, and Smart Watches go through a 3-step quality check before dispatch from our Lahore warehouse. If your product has any manufacturing fault, physical damage, or does not match your order, simply message our WhatsApp support with your Order ID within 7 days of delivery. Return pickup or courier drop-off is arranged swiftly, and 100% of your product amount is refunded or replaced without hidden deductions.',
  },
  visitorStats: {
    liveVisitors: 27,
    todayVisitors: 486,
    totalVisitors: 18420,
    weeklyTraffic: [
      { day: 'Thu', visitors: 390, orders: 0, sales: 0 },
      { day: 'Fri', visitors: 520, orders: 0, sales: 0 },
      { day: 'Sat', visitors: 610, orders: 0, sales: 0 },
      { day: 'Sun', visitors: 680, orders: 0, sales: 0 },
      { day: 'Mon', visitors: 440, orders: 0, sales: 0 },
      { day: 'Tue', visitors: 465, orders: 0, sales: 0 },
      { day: 'Wed', visitors: 486, orders: 0, sales: 0 },
    ],
  },
  demoBaseline: {
    enabled: false,
    extraTotalOrders: 0,
    extraDeliveredOrders: 0,
    extraReturnedOrders: 0,
    extraPendingOrders: 0,
    extraSalesAmount: 0,
  },
};
