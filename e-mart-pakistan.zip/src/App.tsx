import { useState, useEffect, useCallback, useRef } from 'react';
import { ShieldCheck, Truck, RotateCcw, MessageCircle, SlidersHorizontal } from 'lucide-react';
import { initialStoreData } from './data/initialStoreData';
import { CODOrder, OrderStatus, Product, StoreState } from './types/store';
import {
  addCloudProduct,
  createCloudOrder,
  deleteCloudOrder,
  deleteCloudProduct,
  fetchCloudStore,
  fetchCloudVersion,
  purgeLegacyLocalCache,
  saveCloudStorePartial,
  sendVisitorHeartbeat,
  updateCloudOrderStatus,
  updateCloudProduct,
} from './utils/cloudApi';
import { Header } from './components/Header';
import { HeroSlider } from './components/HeroSlider';
import { CategoryCircles } from './components/CategoryCircles';
import { ProductCard } from './components/ProductCard';
import { ProductDetailPage } from './components/ProductDetailPage';
import { ReturnPolicyAndFooter } from './components/ReturnPolicyAndFooter';
import { OrderTrackingModal } from './components/OrderTrackingModal';
import { AdminPortal } from './components/AdminPortal';

// Ensure no device ever relies on stale localStorage store data
purgeLegacyLocalCache();

export default function App() {
  const [storeState, setStoreState] = useState<StoreState>(initialStoreData);
  const lastUpdatedAtRef = useRef<number>(0);

  const [currentView, setCurrentView] = useState<'home' | 'product' | 'admin'>('home');
  const [selectedProductSlug, setSelectedProductSlug] = useState<string | null>(null);
  const [activeCategory, setActiveCategory] = useState<string>('ALL');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [sortBy, setSortBy] = useState<'featured' | 'price_asc' | 'price_desc' | 'rating'>(
    'featured'
  );
  const [trackModalOpen, setTrackModalOpen] = useState(false);

  const applyCloudStoreState = useCallback((cloudData: StoreState) => {
    if (!cloudData || !cloudData.products) return;
    lastUpdatedAtRef.current = cloudData.updatedAt || Date.now();
    setStoreState(cloudData);
  }, []);

  // Sync URL query parameter (?product=slug) or path (/product/slug) on load & popstate
  const syncRouteFromUrl = useCallback((productsList: Product[]) => {
    const params = new URLSearchParams(window.location.search);
    const productParam = params.get('product');
    const adminParam = params.get('admin');

    if (adminParam === '1' || window.location.pathname === '/admin') {
      setCurrentView('admin');
      return;
    }

    let targetSlug = productParam;
    if (!targetSlug && window.location.pathname.startsWith('/product/')) {
      targetSlug = decodeURIComponent(
        window.location.pathname.replace('/product/', '').replace(/\/+$/, '')
      );
    }

    if (targetSlug) {
      const found = productsList.find(
        (p) => p.slug.toLowerCase() === targetSlug!.toLowerCase() || p.id === targetSlug
      );
      if (found) {
        setSelectedProductSlug(found.slug);
        setCurrentView('product');
        return;
      }
    }
  }, []);

  // Refresh latest data directly from the centralized online cloud database
  const refreshFromCloud = useCallback(async () => {
    try {
      const serverData = await fetchCloudStore();
      if (serverData && serverData.products) {
        applyCloudStoreState(serverData);
        return serverData;
      }
    } catch {
      // ignore transient network blip
    }
    return null;
  }, [applyCloudStoreState]);

  // Load state from centralized cloud database on mount + real-time version sync + visitor heartbeat
  useEffect(() => {
    let isMounted = true;

    async function initStore() {
      const serverData = await refreshFromCloud();
      if (isMounted) {
        syncRouteFromUrl((serverData || initialStoreData).products);
      }
    }

    initStore();

    // Visitor Heartbeat for Live Visitor Counter
    let sessionId = '';
    let isNewVisit = false;
    try {
      sessionId = sessionStorage.getItem('emart_visitor_sid') || '';
      if (!sessionId) {
        isNewVisit = true;
        sessionId = `vis-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
        sessionStorage.setItem('emart_visitor_sid', sessionId);
      }
    } catch {
      sessionId = `vis-${Date.now()}`;
    }

    const pingHeartbeat = async (firstPing: boolean) => {
      try {
        const stats = await sendVisitorHeartbeat(sessionId, firstPing);
        if (!isMounted) return;
        setStoreState((prev) => ({
          ...prev,
          visitorStats: {
            ...prev.visitorStats,
            liveVisitors: stats.liveVisitors ?? prev.visitorStats.liveVisitors,
            todayVisitors: stats.todayVisitors ?? prev.visitorStats.todayVisitors,
            totalVisitors: stats.totalVisitors ?? prev.visitorStats.totalVisitors,
          },
        }));
      } catch {
        // ignore network hiccup
      }
    };

    pingHeartbeat(isNewVisit);

    // Poll cloud database version every 4 seconds so any admin change on any device updates all customers live
    const checkCloudVersion = async () => {
      try {
        const ver = await fetchCloudVersion();
        if (!isMounted) return;
        if (ver.updatedAt && ver.updatedAt !== lastUpdatedAtRef.current) {
          await refreshFromCloud();
        } else {
          setStoreState((prev) => ({
            ...prev,
            visitorStats: {
              ...prev.visitorStats,
              liveVisitors: ver.liveVisitors ?? prev.visitorStats.liveVisitors,
              todayVisitors: ver.todayVisitors ?? prev.visitorStats.todayVisitors,
              totalVisitors: ver.totalVisitors ?? prev.visitorStats.totalVisitors,
            },
          }));
        }
      } catch {
        // ignore transient poll error
      }
    };

    const syncInterval = setInterval(checkCloudVersion, 4000);
    const heartbeatInterval = setInterval(() => pingHeartbeat(false), 30000);

    const handleVisibilityOrFocus = () => {
      if (document.visibilityState === 'visible') {
        checkCloudVersion();
      }
    };

    const handlePopState = () => {
      const params = new URLSearchParams(window.location.search);
      const slug = params.get('product');
      if (slug) {
        setSelectedProductSlug(slug);
        setCurrentView('product');
      } else {
        setSelectedProductSlug(null);
        setCurrentView('home');
      }
    };

    window.addEventListener('focus', handleVisibilityOrFocus);
    document.addEventListener('visibilitychange', handleVisibilityOrFocus);
    window.addEventListener('popstate', handlePopState);

    return () => {
      isMounted = false;
      clearInterval(syncInterval);
      clearInterval(heartbeatInterval);
      window.removeEventListener('focus', handleVisibilityOrFocus);
      document.removeEventListener('visibilitychange', handleVisibilityOrFocus);
      window.removeEventListener('popstate', handlePopState);
    };
  }, [refreshFromCloud, syncRouteFromUrl]);

  // Navigate to a specific product page and update URL for Meta Ads compatibility
  const handleSelectProduct = (product: Product) => {
    setSelectedProductSlug(product.slug);
    setCurrentView('product');
    const newUrl = `${window.location.pathname}?product=${encodeURIComponent(product.slug)}`;
    window.history.pushState({ product: product.slug }, '', newUrl);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleNavigateHome = () => {
    setCurrentView('home');
    setSelectedProductSlug(null);
    window.history.pushState({}, '', window.location.pathname);
    window.scrollTo({ top: 0, behavior: 'smooth' });
    refreshFromCloud();
  };

  const handleNavigateAdmin = () => {
    setCurrentView('admin');
    window.scrollTo({ top: 0, behavior: 'smooth' });
    refreshFromCloud();
  };

  // Persist store updates directly to Centralized Online Cloud Database
  const handleUpdateStore = async (partial: Partial<StoreState>) => {
    setStoreState((prev) => ({
      ...prev,
      ...partial,
    }));
    const saved = await saveCloudStorePartial(partial);
    applyCloudStoreState(saved);
  };

  // Add Product to Centralized Cloud Database
  const handleAddProduct = async (product: Product) => {
    setStoreState((prev) => ({
      ...prev,
      products: [product, ...prev.products],
    }));
    const res = await addCloudProduct(product);
    applyCloudStoreState(res.store);
  };

  // Update Product in Centralized Cloud Database
  const handleUpdateProduct = async (product: Product) => {
    setStoreState((prev) => ({
      ...prev,
      products: prev.products.map((p) => (p.id === product.id ? product : p)),
    }));
    const res = await updateCloudProduct(product);
    applyCloudStoreState(res.store);
  };

  // Delete Product from Centralized Cloud Database
  const handleDeleteProduct = async (productId: string) => {
    setStoreState((prev) => ({
      ...prev,
      products: prev.products.filter((p) => p.id !== productId),
    }));
    const res = await deleteCloudProduct(productId);
    applyCloudStoreState(res.store);
  };

  // Submit COD Order from Product Page directly to Centralized Cloud Database
  const handleSubmitCODOrder = async (
    orderPayload: Omit<CODOrder, 'id' | 'orderNumber' | 'createdAt' | 'status'>
  ): Promise<CODOrder> => {
    const res = await createCloudOrder(orderPayload);
    applyCloudStoreState(res.store);
    return res.order;
  };

  // Update Order Status in Centralized Cloud Database
  const handleUpdateOrderStatus = async (orderId: string, status: OrderStatus) => {
    setStoreState((prev) => ({
      ...prev,
      orders: prev.orders.map((o) => (o.id === orderId ? { ...o, status } : o)),
    }));
    const res = await updateCloudOrderStatus(orderId, status);
    applyCloudStoreState(res.store);
  };

  // Delete Order from Centralized Cloud Database
  const handleDeleteOrder = async (orderId: string) => {
    setStoreState((prev) => ({
      ...prev,
      orders: prev.orders.filter((o) => o.id !== orderId),
    }));
    const res = await deleteCloudOrder(orderId);
    applyCloudStoreState(res.store);
  };

  // Filter & Sort Products for Homepage Grid
  const filteredProducts = storeState.products
    .filter((p) => {
      const matchesCat =
        activeCategory === 'ALL' ||
        p.category.toLowerCase() === activeCategory.toLowerCase();
      const q = searchQuery.trim().toLowerCase();
      const matchesSearch =
        !q ||
        p.name.toLowerCase().includes(q) ||
        p.category.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q);
      return matchesCat && matchesSearch;
    })
    .sort((a, b) => {
      if (sortBy === 'price_asc') return a.price - b.price;
      if (sortBy === 'price_desc') return b.price - a.price;
      if (sortBy === 'rating') return b.rating - a.rating;
      return 0;
    });

  const activeProduct =
    storeState.products.find((p) => p.slug === selectedProductSlug) ||
    storeState.products[0];

  return (
    <div className="min-h-screen flex flex-col bg-[#FAF9F6] text-stone-900">
      {/* Top Announcement Ticker + Bordered Navigation + E Mart Logo */}
      <Header
        settings={storeState.settings}
        categories={storeState.categories}
        activeCategory={activeCategory}
        searchQuery={searchQuery}
        liveVisitors={storeState.visitorStats.liveVisitors}
        currentView={currentView}
        onSelectCategory={(cat) => setActiveCategory(cat)}
        onSearchChange={(q) => setSearchQuery(q)}
        onNavigateHome={handleNavigateHome}
        onNavigateAdmin={handleNavigateAdmin}
        onOpenTrackModal={() => setTrackModalOpen(true)}
      />

      {/* VIEW 1: ADMIN PORTAL */}
      {currentView === 'admin' && (
        <AdminPortal
          storeState={storeState}
          onUpdateStore={handleUpdateStore}
          onAddProduct={handleAddProduct}
          onUpdateProduct={handleUpdateProduct}
          onDeleteProduct={handleDeleteProduct}
          onUpdateOrderStatus={handleUpdateOrderStatus}
          onDeleteOrder={handleDeleteOrder}
          onOpenProductPage={(prod) => handleSelectProduct(prod)}
          onExitAdmin={handleNavigateHome}
        />
      )}

      {/* VIEW 2: DEDICATED PRODUCT DETAIL PAGE (Also opened directly from Meta Ad URLs) */}
      {currentView === 'product' && activeProduct && (
        <main className="flex-1">
          <ProductDetailPage
            product={activeProduct}
            settings={storeState.settings}
            relatedProducts={storeState.products.filter((p) => p.id !== activeProduct.id)}
            onBackToStore={handleNavigateHome}
            onSelectProduct={handleSelectProduct}
            onSubmitCODOrder={handleSubmitCODOrder}
          />
        </main>
      )}

      {/* VIEW 3: STOREFRONT HOMEPAGE */}
      {currentView === 'home' && (
        <main className="flex-1">
          {/* 3-Banner Rotating Hero Section */}
          <HeroSlider
            banners={storeState.banners}
            rotationSeconds={storeState.settings.bannerRotationSeconds}
            onSelectCategory={(cat) => setActiveCategory(cat)}
          />

          {/* Circular Category Icons/Cards */}
          <CategoryCircles
            categories={storeState.categories}
            products={storeState.products}
            activeCategory={activeCategory}
            onSelectCategory={(cat) => setActiveCategory(cat)}
          />

          {/* Product Listings Grid */}
          <section
            id="products-grid-section"
            aria-label="Featured Products"
            className="max-w-7xl mx-auto px-3 sm:px-6 lg:px-8 py-4 sm:py-8"
          >
            {/* Grid Header & Sort Controls */}
            <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3 pb-5 mb-6 border-b border-stone-200/90">
              <div>
                <p className="text-[11px] sm:text-xs font-bold uppercase tracking-wider text-emerald-800">
                  100% Original & Quality Inspected
                </p>
                <h2 className="text-xl sm:text-2xl lg:text-3xl font-extrabold text-stone-950 tracking-tight">
                  {activeCategory === 'ALL'
                    ? 'Featured Store Catalog'
                    : `${activeCategory} Collection`}
                </h2>
              </div>

              <div className="flex items-center justify-between sm:justify-end gap-3">
                <span className="text-xs text-stone-500 font-mono-tabular">
                  Showing <strong>{filteredProducts.length}</strong> products
                </span>

                <div className="flex items-center gap-1.5 bg-white border border-stone-200/90 rounded-xl px-3 py-1.5 text-xs">
                  <SlidersHorizontal className="w-3.5 h-3.5 text-stone-500" />
                  <select
                    value={sortBy}
                    onChange={(e) =>
                      setSortBy(
                        e.target.value as 'featured' | 'price_asc' | 'price_desc' | 'rating'
                      )
                    }
                    className="bg-transparent font-semibold text-stone-800 focus:outline-none cursor-pointer"
                  >
                    <option value="featured">Sort: Featured Deals</option>
                    <option value="price_asc">Price: Low to High</option>
                    <option value="price_desc">Price: High to Low</option>
                    <option value="rating">Top 5-Star Rated</option>
                  </select>
                </div>
              </div>
            </div>

            {filteredProducts.length === 0 ? (
              <div className="bg-white rounded-2xl border border-stone-200 p-12 text-center space-y-3">
                <p className="text-base font-bold text-stone-800">
                  No products found matching your filter.
                </p>
                <button
                  type="button"
                  onClick={() => {
                    setActiveCategory('ALL');
                    setSearchQuery('');
                  }}
                  className="px-4 py-2 bg-emerald-700 text-white text-xs font-bold rounded-xl cursor-pointer"
                >
                  Show All Products
                </button>
              </div>
            ) : (
              <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-3 sm:gap-6">
                {filteredProducts.map((product) => (
                  <ProductCard
                    key={product.id}
                    product={product}
                    whatsappNumber={storeState.settings.whatsappNumber}
                    onSelectProduct={handleSelectProduct}
                  />
                ))}
              </div>
            )}

            {/* Store Trust Bar */}
            <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-5">
              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 flex items-start gap-3">
                <Truck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-stone-950">
                    Fast Nationwide COD
                  </h3>
                  <p className="text-[11px] sm:text-xs text-stone-500 mt-0.5">
                    Pay cash at your doorstep in Karachi, Lahore, Islamabad & all cities.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 flex items-start gap-3">
                <ShieldCheck className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-stone-950">
                    Quality Checked Items
                  </h3>
                  <p className="text-[11px] sm:text-xs text-stone-500 mt-0.5">
                    Every product is tested by our QC team before packing.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 flex items-start gap-3">
                <RotateCcw className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-stone-950">
                    7-Day Return Policy
                  </h3>
                  <p className="text-[11px] sm:text-xs text-stone-500 mt-0.5">
                    Easy replacement or refund via JazzCash, EasyPaisa & Bank.
                  </p>
                </div>
              </div>

              <div className="p-4 rounded-2xl bg-white border border-stone-200/80 flex items-start gap-3">
                <MessageCircle className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" />
                <div>
                  <h3 className="text-xs sm:text-sm font-bold text-stone-950">
                    24/7 WhatsApp Support
                  </h3>
                  <p className="text-[11px] sm:text-xs text-stone-500 mt-0.5">
                    Direct order confirmation & tracking on WhatsApp.
                  </p>
                </div>
              </div>
            </div>
          </section>
        </main>
      )}

      {/* Return & Refund Policy Section + Professional Footer + Floating WhatsApp Button */}
      {currentView !== 'admin' && (
        <ReturnPolicyAndFooter
          returnPolicy={storeState.returnPolicy}
          settings={storeState.settings}
          categories={storeState.categories}
          visitorStats={storeState.visitorStats}
          onSelectCategory={(cat) => setActiveCategory(cat)}
          onNavigateHome={handleNavigateHome}
          onNavigateAdmin={handleNavigateAdmin}
          onOpenTrackModal={() => setTrackModalOpen(true)}
        />
      )}

      {/* Order Tracking Modal */}
      <OrderTrackingModal
        isOpen={trackModalOpen}
        orders={storeState.orders}
        onClose={() => setTrackModalOpen(false)}
      />
    </div>
  );
}
