export function formatPKR(amount: number): string {
  const safeNum = Number.isFinite(amount) ? Math.round(amount) : 0;
  return `Rs. ${safeNum.toLocaleString('en-PK')}`;
}

export function slugify(text: string): string {
  return text
    .toString()
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9\s-]/g, '')
    .replace(/\s+/g, '-')
    .replace(/-+/g, '-')
    .replace(/^-+|-+$/g, '');
}

export function buildProductShareUrl(slug: string): string {
  if (typeof window === 'undefined') {
    return `/?product=${encodeURIComponent(slug)}`;
  }
  const baseUrl = `${window.location.origin}${window.location.pathname.replace(/\/+$/, '') || '/'}`;
  return `${baseUrl}?product=${encodeURIComponent(slug)}`;
}

export function normalizePakistanPhone(raw: string): string {
  let digits = (raw || '').replace(/\D/g, '');
  if (!digits) return '923008492026';
  if (digits.startsWith('0092')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('03') && digits.length === 11) {
    digits = '92' + digits.slice(1);
  } else if (digits.startsWith('3') && digits.length === 10) {
    digits = '92' + digits;
  }
  return digits;
}

export function buildWhatsAppUrl(rawPhone: string, message: string): string {
  const cleanPhone = normalizePakistanPhone(rawPhone);
  return `https://wa.me/${cleanPhone}?text=${encodeURIComponent(message)}`;
}

export function calculateDiscountPercent(price: number, oldPrice: number): number {
  if (!oldPrice || oldPrice <= price || price <= 0) return 0;
  return Math.round(((oldPrice - price) / oldPrice) * 100);
}

/**
 * Reads an uploaded image File from the user's PC and optimizes it into a high-clarity Data URL.
 */
export function readAndCompressImageFile(
  file: File,
  maxWidth = 1280,
  quality = 0.86
): Promise<string> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onerror = () => reject(new Error('Failed to read image file'));
    reader.onload = () => {
      const result = reader.result as string;
      // If SVG or small file, return directly
      if (file.type === 'image/svg+xml' || file.size < 180 * 1024) {
        resolve(result);
        return;
      }
      const img = new Image();
      img.onload = () => {
        try {
          let width = img.width;
          let height = img.height;
          if (width > maxWidth) {
            height = Math.round((height * maxWidth) / width);
            width = maxWidth;
          }
          const canvas = document.createElement('canvas');
          canvas.width = width;
          canvas.height = height;
          const ctx = canvas.getContext('2d');
          if (!ctx) {
            resolve(result);
            return;
          }
          ctx.drawImage(img, 0, 0, width, height);
          const compressed = canvas.toDataURL('image/jpeg', quality);
          resolve(compressed);
        } catch {
          resolve(result);
        }
      };
      img.onerror = () => resolve(result);
      img.src = result;
    };
    reader.readAsDataURL(file);
  });
}
