import { CODOrder, OrderStatus, Product, StoreState } from '../types/store';

// Centralized Cloud Backend URLs (used automatically if deployed to a static host like Netlify)
const PRIMARY_CLOUD_ORIGINS: string[] = [
  '', // 1. Same-origin /api (Cloud Run & Netlify proxy)
  (import.meta as unknown as { env?: Record<string, string> }).env?.VITE_CLOUD_API_URL || '',
  'https://ais-pre-flooktj6sipkyyasuqfnty-408181072994.asia-east1.run.app',
  'https://ais-dev-flooktj6sipkyyasuqfnty-408181072994.asia-east1.run.app',
].filter((v, i, arr) => arr.indexOf(v) === i);

let resolvedOrigin: string | null = null;

/**
 * Purges any legacy localStorage store caches so the website never depends on
 * device-local storage and always uses the single shared online cloud database.
 */
export function purgeLegacyLocalCache(): void {
  try {
    localStorage.removeItem('emart_pakistan_store_v1');
    localStorage.removeItem('emart_custom_admin_pass');
  } catch {
    // ignore storage errors in restricted webviews
  }
}

function buildApiUrl(origin: string, endpoint: string, bustCache = false): string {
  const cleanOrigin = origin.replace(/\/+$/, '');
  const cleanEndpoint = endpoint.startsWith('/') ? endpoint : `/${endpoint}`;
  const separator = cleanEndpoint.includes('?') ? '&' : '?';
  const suffix = bustCache ? `${separator}_t=${Date.now()}` : '';
  return `${cleanOrigin}${cleanEndpoint}${suffix}`;
}

/**
 * Performs an HTTP request against the centralized online cloud database,
 * automatically verifying JSON response and falling back across cloud origins if hosted on static Netlify.
 */
export async function cloudRequest<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<T> {
  const isGet = !options.method || options.method.toUpperCase() === 'GET';
  const headers: Record<string, string> = {
    Accept: 'application/json',
    'Cache-Control': 'no-cache, no-store, must-revalidate',
    Pragma: 'no-cache',
    ...(options.headers as Record<string, string> | undefined),
  };

  if (options.body && !headers['Content-Type']) {
    headers['Content-Type'] = 'application/json';
  }

  const candidateOrigins =
    resolvedOrigin !== null
      ? [resolvedOrigin, ...PRIMARY_CLOUD_ORIGINS.filter((o) => o !== resolvedOrigin)]
      : PRIMARY_CLOUD_ORIGINS;

  let lastError: Error | null = null;

  for (const origin of candidateOrigins) {
    try {
      const url = buildApiUrl(origin, endpoint, isGet);
      const response = await fetch(url, {
        ...options,
        headers,
        cache: 'no-store',
        mode: origin === '' ? 'same-origin' : 'cors',
      });

      const contentType = response.headers.get('content-type') || '';
      // If a static host (e.g. Netlify SPA fallback) returned HTML instead of JSON, try the next cloud origin
      if (!contentType.includes('application/json')) {
        continue;
      }

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data?.error || `Cloud request failed with status ${response.status}`);
      }

      resolvedOrigin = origin;
      return data as T;
    } catch (err) {
      lastError = err instanceof Error ? err : new Error(String(err));
      // If it was an explicit 401/400 business error from JSON, rethrow immediately
      if (
        lastError.message.includes('Incorrect admin') ||
        lastError.message.includes('Password must be') ||
        lastError.message.includes('Current password')
      ) {
        throw lastError;
      }
    }
  }

  throw lastError || new Error('Unable to reach centralized cloud database');
}

export async function fetchCloudStore(): Promise<StoreState> {
  return cloudRequest<StoreState>('/api/store', { method: 'GET' });
}

export interface CloudVersionResponse {
  updatedAt: number;
  liveVisitors: number;
  todayVisitors: number;
  totalVisitors: number;
  productsCount: number;
  ordersCount: number;
}

export async function fetchCloudVersion(): Promise<CloudVersionResponse> {
  return cloudRequest<CloudVersionResponse>('/api/store/version', { method: 'GET' });
}

export async function saveCloudStorePartial(
  partial: Partial<StoreState>
): Promise<StoreState> {
  return cloudRequest<StoreState>('/api/store', {
    method: 'PUT',
    body: JSON.stringify(partial),
  });
}

export async function addCloudProduct(
  product: Product
): Promise<{ product: Product; store: StoreState }> {
  return cloudRequest<{ product: Product; store: StoreState }>('/api/products', {
    method: 'POST',
    body: JSON.stringify(product),
  });
}

export async function updateCloudProduct(
  product: Product
): Promise<{ product: Product; store: StoreState }> {
  return cloudRequest<{ product: Product; store: StoreState }>(
    `/api/products/${encodeURIComponent(product.id)}`,
    {
      method: 'PUT',
      body: JSON.stringify(product),
    }
  );
}

export async function deleteCloudProduct(
  productId: string
): Promise<{ store: StoreState }> {
  return cloudRequest<{ store: StoreState }>(
    `/api/products/${encodeURIComponent(productId)}`,
    {
      method: 'DELETE',
    }
  );
}

export async function createCloudOrder(
  orderPayload: Omit<CODOrder, 'id' | 'orderNumber' | 'createdAt' | 'status'>
): Promise<{ order: CODOrder; store: StoreState }> {
  return cloudRequest<{ order: CODOrder; store: StoreState }>('/api/orders', {
    method: 'POST',
    body: JSON.stringify(orderPayload),
  });
}

export async function updateCloudOrderStatus(
  orderId: string,
  status: OrderStatus
): Promise<{ order: CODOrder; store: StoreState }> {
  return cloudRequest<{ order: CODOrder; store: StoreState }>(
    `/api/orders/${encodeURIComponent(orderId)}`,
    {
      method: 'PATCH',
      body: JSON.stringify({ status }),
    }
  );
}

export async function deleteCloudOrder(orderId: string): Promise<{ store: StoreState }> {
  return cloudRequest<{ store: StoreState }>(
    `/api/orders/${encodeURIComponent(orderId)}`,
    {
      method: 'DELETE',
    }
  );
}

export async function sendVisitorHeartbeat(
  sessionId: string,
  isNewVisit: boolean
): Promise<{
  updatedAt: number;
  liveVisitors: number;
  todayVisitors: number;
  totalVisitors: number;
}> {
  return cloudRequest('/api/visitors/heartbeat', {
    method: 'POST',
    body: JSON.stringify({ sessionId, isNewVisit }),
  });
}

export async function loginCloudAdmin(
  username: string,
  password: string
): Promise<{ authenticated: boolean; username: string; token: string }> {
  return cloudRequest('/api/admin/login', {
    method: 'POST',
    body: JSON.stringify({ username, password }),
  });
}

export async function changeCloudAdminPassword(
  username: string,
  currentPassword: string,
  newPassword: string
): Promise<{ success: boolean; username: string; store: StoreState }> {
  return cloudRequest('/api/admin/password', {
    method: 'PUT',
    body: JSON.stringify({ username, currentPassword, newPassword }),
  });
}
